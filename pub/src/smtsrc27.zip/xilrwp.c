/*  ----------------------------------------------------------------<Prolog>-
    Name:       xilrwp.c
    Title:      Xitami WSX agent for long-running web process (LRWP) protocol
    Package:    Xitami

    Written:    97/10/29    Robin P. Dunn  Total Control Software
    Revised:    99/06/28    EM: Updated for LRWP 2.0

    Copyright:  Copyright (c) 1991-99 iMatix Corporation
    License:    This is free software; you can redistribute it and/or modify
                it under the terms of the SMT License Agreement as provided
                in the file LICENSE.TXT.  This software is distributed in
                the hope that it will be useful, but without any warranty.
 ------------------------------------------------------------------</Prolog>-*/

#include "smtdefn.h"                    /*  SMT Agent Definitions            */
#include "smthttpl.h"                   /*  SMT HTTP library                 */

#include "xilrwp.h"                     /* LWRP definitions, etc.            */


/*- Definitions -------------------------------------------------------------*/

#undef  AGENT_NAME
#define AGENT_NAME          LRWP_NAME

#define LRWP_REQUEST        "LRWP_REQUEST"
#define LRWP_PEERCLOSED     "LRWP_PEERCLOSED"
#define LRWP_JOBCOMP        "LRWP_JOBCOMP"

#define WSX_REQUEST         "WSX_REQUEST"


#define _MASTER             "_MASTER"
#define _PEER               "_PEER"
#define _ROUTER             "_ROUTER"

#define CHALLENGE_LENGTH    32          /* LRWP 2.0 auth challenge           */
#define LRWP_STRING_DELIM      "\xFF"   /* Delimiter as string; to send      */
#define LRWP_STRING_DELIM_CHAR '\xFF'   /* Delimiter as char; to search for  */

#define MAX_APPNAME_LEN     200         /* XXX: Arbitrary values--rationalise*/
#define MAX_VHOST_LEN       200
#define BIG_RESPONSE_LEN    16384       /* Below this, keep in memory        */

#define LENGTH_LEN          9           /* Digits in length val to/from peer */
#define LENGTH_FORMAT       "%09d"      /* sprintf() arg to build length     */
#define LENGTH_FORMAT_LONG  "%09ld"     /* above for int; this for long      */

/*---------------------------------------------------------------------------*/

typedef struct {
    char*   name;
    char*   vhost;
    NODE    peerList;                   /* A list of PTCB's                  */
    NODE    waitingRequests;            /* A list of REQ's                   */
} RTRData;


typedef struct {                        /* Peer Thread control block         */
    void    *next, *prev;
    THREAD* thread;
    int     busy;
} PTCB;

typedef struct {                        /* Waiting requests                  */
    void    *next, *prev;
    WSXREQ* wsxreq;
    QID     replyQ;
} REQ;

typedef struct {                        /*  Thread context block:            */
    /* all types use this */
    int         thread_type;

    /* master and peers */
    int         handle;

    /* peers only */
    int         proto_major;            /*  LRWP Protocol 1.0, 2.0, etc      */
    int         proto_minor;
    char*       appName;                /*  LRWP connection details          */
    char*       vhost;
    char*       filterExt;
    byte        challenge[CHALLENGE_LENGTH];  /*  LRWP 2.0 auth challenge    */
    const char* startupError;           /*  Pointer to startup error (if any)*/
    char*       sockError;              /*  Copy of socket error msg         */

    PTCB*       ptcb;
    RTRData*    rtr;
    QID         replyQ;
    char        sizebuff[LENGTH_LEN + 1];
    size_t      numtoread;
    size_t      numread;
    char*       buffer;

    /* router only */
    Bool        termWhenEmpty;
} LRWP_TCB;


/*- Function prototypes -----------------------------------------------------*/

static char* makeTableKey         (char* name, char* vhost);
static void  sendPeerErrorMessage (int handle, const char *errorMessage, 
                                   int lrwpVer);
static char* makeLRWPAppKey       (char* appName);


/*- Global variables used in this source file only --------------------------*/

static LRWP_TCB  *tcb;                   /*  Address thread context block    */
#define TCB     LRWP_TCB

static QID  operq,                       /*  Operator console event queue    */
            /*logq, */                   /*  Logging agent event queue       */
            sockq,                       /*  Socket agent event queue        */
            tranq;                       /*  Transfer Agent                  */

static SYMTAB*  peerTable = NULL;
static THREAD*  rtrThread;
static THREAD*  http_thread;


#include "xilrwp.d"                      /*  Include dialog data             */


/********************   INITIALISE AGENT - ENTRY POINT   *********************/

int xilrwp_init (void)
{
    THREAD  *thread;
    AGENT   *agent;                     /*  Handle for our agent             */
#   include "xilrwp.i"                  /*  Include dialog interpreter       */

    /*  Change any of the agent properties that you need to                  */
    agent->router      = FALSE;         /*  FALSE = default                  */
    agent->max_threads = 0;             /*  0 = default                      */

    /*                      Method name     Event value      Priority        */
    /*  Shutdown event comes from Kernel                                     */
    method_declare(agent, "SHUTDOWN",       shutdown_event,  SMT_PRIORITY_MAX);

    /*  Reply events from socket agent                                       */
    method_declare(agent, "SOCK_INPUT_OK",  sock_input_ok_event,       0);
    method_declare(agent, "SOCK_CLOSED",    sock_closed_event,         0);
    method_declare(agent, "SOCK_ERROR",     sock_error_event,          0);
    method_declare(agent, "SOCK_TIMEOUT",   sock_error_event,          0);
    method_declare(agent, "SOCK_WRITE_OK",  sock_write_ok_event,       0);
    method_declare(agent, "TRAN_PUTF_OK",   sock_write_ok_event,       0);
    method_declare(agent, "TRAN_CLOSED",    sock_closed_event,         0);
    method_declare(agent, "TRAN_ERROR",     sock_error_event,          0);

    /*  Private methods used to pump the initial thread events               */
    method_declare(agent, _MASTER,          master_event,   0);
    method_declare(agent, _PEER,            peer_event,     0);
    method_declare(agent, _ROUTER,          router_event,   0);

    /* other methods this agent supports                                     */
    method_declare(agent, WSX_REQUEST,      wsx_request_event,          0);
    method_declare(agent, LRWP_REQUEST,     lrwp_request_event,         0);
    method_declare(agent, LRWP_PEERCLOSED,  peer_closed_event,          0);
    method_declare(agent, LRWP_JOBCOMP,     peer_job_completed_event,   0);


    /*  Ensure that operator console is running, else start it up            */
    smtoper_init();
    if ((thread = thread_lookup(SMT_OPERATOR, "")) != NULL)
        operq = thread->queue->qid;
    else
        return(-1);

    /*  Ensure that socket agent is running, else start it up                */
    smtsock_init();
    if ((thread = thread_lookup(SMT_SOCKET, "")) != NULL)
        sockq = thread->queue->qid;
    else
        return(-1);

    /*  Ensure that transfer agent is running, else start it up              */
    smttran_init();
    if ((thread = thread_lookup(SMT_TRANSFER, "")) != NULL)
        tranq = thread->queue->qid;
    else
        return(-1);

    /*  Create initial thread to manage listening socket port                */
    if ((thread = thread_create(AGENT_NAME, "")) != NULL) {
        SEND(&thread->queue->qid, _MASTER, "");  /* pump the first event     */
        ((TCB *)thread->tcb)->thread_type = master_event;
        ((TCB *)thread->tcb)->handle      = 0;
      }
    else
        return (-1);

    /*  Create thread to act as the request router, and to respond to the WSX
        messages */
    if ((rtrThread = thread_create(AGENT_NAME, "main")) != NULL) {
        SEND(&rtrThread->queue->qid, _ROUTER, "");  /* pump the first event   */
        ((TCB *)rtrThread->tcb)->thread_type = router_event;
        ((TCB *)rtrThread->tcb)->handle      = 0;
      }
    else
        return (-1);

    /*  Signal to caller that we initialised okay */
    return(0);
}

/*************************   INITIALISE THE THREAD   *************************/

MODULE initialise_the_thread (THREAD *thread)
{
    /* Default initialise TCB structure: but first event pumped in           */
    tcb = thread->tcb;                 /*  Point to thread's context         */

    /* For peer threads                                                      */
    tcb->proto_major  = tcb->proto_minor = 0;
    tcb->appName      = tcb->vhost       = tcb->filterExt = NULL;
    tcb->numtoread    = tcb->numread     = 0;
    tcb->sockError    = NULL;
    tcb->startupError = NULL;
    tcb->buffer       = NULL;
}


/*************************   TERMINATE THE THREAD   **************************/

MODULE terminate_the_thread (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */
    switch (tcb->thread_type) {
        case master_event:
            if (tcb->handle)
                close_socket(tcb->handle);
            break;

        case peer_event:
            if (tcb->handle)
                close_socket(tcb->handle);
            if (tcb->ptcb)
                node_destroy(tcb->ptcb);
            if (tcb->rtr)
                SEND(&rtrThread->queue->qid, LRWP_PEERCLOSED,
                        makeTableKey(tcb->rtr->name, tcb->rtr->vhost));
            if (tcb->appName)
                mem_free(tcb->appName);
            if (tcb->vhost)
                mem_free(tcb->vhost);
            if (tcb->filterExt)
                mem_free(tcb->filterExt);
            break;

        case router_event:
            if (peerTable) {
                tcb->termWhenEmpty = TRUE;
                return;       /* bail out here so thread won't terminate yet */
            }
            break;
    }

    the_next_event = terminate_event;
}



/***************************   OPEN MASTER SOCKET   **************************/

MODULE open_master_socket (THREAD *thread)
{
    int     port;
    char*   cPort;

    tcb = thread->tcb;                 /*  Point to thread's context         */

    cPort = http_config(config, "lrwp:port");
    if (!cPort || !*cPort)             /*  Use default port if not set       */
        cPort = LRWP_PORT;
    port = atoi(cPort) + ip_portbase;
    tcb->handle = passive_TCP(cPort, 5);
    if (tcb->handle == INVALID_SOCKET) {
        sendfmt(&operq, "ERROR",
                LRWP_NAME ": Could not open LRWP port %d", port);
        sendfmt(&operq, "ERROR", connect_errlist[connect_error()]);
        raise_exception(fatal_event);
      }
    else {
        sendfmt(&operq, "INFO",
                 LRWP_NAME ": ready for LRWP connections on port %d", port);
    }

    /* We'll need the main thread in HTTP agent later... */
    http_thread = thread_lookup (SMT_HTTP, "main");
}


/*************************   WAIT FOR SOCKET INPUT   *************************/

MODULE wait_for_socket_input (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */

    send_input(&sockq, 0, tcb->handle, 0);
}

/******************************   SETUP ROUTER   *****************************/

MODULE setup_router (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */
    tcb->termWhenEmpty = FALSE;
}

/************************   ACCEPT PEER CONNECTION   ***********************/

MODULE accept_peer_connection (THREAD *thread)
{
    sock_t  slave_socket;              /*  Connected socket                  */
    THREAD  *peer_thread;              /*  Handle to child threads           */

    tcb = thread->tcb;                 /*  Point to thread's context         */

    slave_socket = accept_socket(tcb->handle);
    if (slave_socket != INVALID_SOCKET) {
        peer_thread = thread_create(AGENT_NAME, "");
        if (peer_thread) {
            SEND(&peer_thread->queue->qid, _PEER, "");
            ((TCB *)peer_thread->tcb)->thread_type = peer_event;
            ((TCB *)peer_thread->tcb)->handle      = slave_socket;
            ((TCB *)peer_thread->tcb)->ptcb        = NULL;
            ((TCB *)peer_thread->tcb)->rtr         = NULL;
        }
        else {
            sendfmt(&operq, "ERROR",
                     LRWP_NAME ": could not create new thread");
            raise_exception(exception_event);
        }
    }
    else if (sockerrno != EAGAIN && sockerrno != EWOULDBLOCK) {
        sendfmt(&operq, "ERROR",
                 LRWP_NAME ": could not accept connection: %s", sockmsg());
        raise_exception(exception_event);
    }
    else {
        sendfmt(&operq, "ERROR",
                 LRWP_NAME ": got EAGAIN accepting new connection: %s", 
                 sockmsg());
        raise_exception(exception_event);
    }
}


/**************************   SIGNAL SOCKET ERROR   **************************/

MODULE signal_socket_error (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */

    if (tcb->sockError) {
        sendfmt(&operq, "ERROR",
                LRWP_NAME ": error on socket: %s", tcb->sockError);

         mem_strfree(&tcb->sockError);
    }
    else {
        /* NOTE: may be a race here between whatever causes the error,
         * and actually retreiving it to print out.  Where possible
         * should save error into tcb->sockError().
         */
        sendfmt(&operq, "ERROR",
                LRWP_NAME ": error on socket: %s", sockmsg());
    }
}


/************************   SHUTDOWN THE APPLICATION   ***********************/

MODULE shutdown_the_application (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */
    smt_shutdown();                    /*  Halt the application              */
}


/*********************   READ APP CONNECTION REQUEST     *********************/

/*  Build string "name:vhost" for indexing LRWP peer tables                  */
/*  If strings will not fit, returns NULL (caller should check this first)   */
static char* makeTableKey(char* name, char* vhost)
{
#define MAX_TABLEKEY_LEN  (MAX_APPNAME_LEN + MAX_VHOST_LEN + 2)

    static char tablekey[MAX_TABLEKEY_LEN];

    vhost = ((vhost && *vhost) ? vhost : VHOST_ANY);

    ASSERT(name  && strlen(name) <= MAX_APPNAME_LEN);
    ASSERT(vhost && strlen(vhost) <= MAX_VHOST_LEN);

    if ((strlen(name) + strlen(vhost) + 2) > MAX_TABLEKEY_LEN)
        return NULL;                             /*  Won't fit!              */

    /* XXX: snprintf()? */
    sprintf(tablekey, "%s:%s", vhost, name);
    return tablekey;
}

/*  Build string "lrwp-application:name" for readind configuration           */
/*  If strings will not fit, returns NULL (caller should check this first)   */
static char* makeLRWPAppKey(char* appName)
{
#define LRWP_APP_PREFIX       "lrwp-application"
#define LRWP_APP_PREFIX_LEN   16
#define MAX_APPKEY_LEN        (MAX_APPNAME_LEN + LRWP_APP_PREFIX_LEN + 2)

    static char appkey[MAX_APPKEY_LEN];
    const char *lrwp_app_prefix = LRWP_APP_PREFIX;

    ASSERT(strlen(lrwp_app_prefix) == LRWP_APP_PREFIX_LEN);
    ASSERT(appName && strlen(appName) <= MAX_APPNAME_LEN);

    if ((strlen(lrwp_app_prefix) + strlen(appName) + 2) > MAX_APPKEY_LEN)
        return NULL;                             /*  Won't fit!              */

    /* XXX: snprintf()? */
    sprintf(appkey, "lrwp-application:%s", appName);
    return appkey;
}

MODULE read_app_connection_request (THREAD *thread)
{
    int         num;
    char        buff[LRWP_MAXSTARTUP];
    char*       webmask;
    char*       access;
    char*       appName     = NULL;
    char*       vhost       = NULL;
    char*       filterExt   = NULL;
    int         proto_major = 0;
    int         proto_minor = 0;

    char        delim = LRWP_STRING_DELIM_CHAR;

    /* Error messages that may be used with LRWP1 should be prefixed
     * with ERROR: for backwards compatibility.  LRWP2 messages can
     * simply state the text of the message.
     */
    const char* errUnrecognisedVersion = "ERROR: Unknown LRWP version";
    const char* errLRWP1Malformed      = "ERROR: Malformed startup string";
    const char* errLRWP2Malformed      = "Malformed LRWP2 connection string";
    const char* errUnauthorised        = "ERROR: Unauthorized access";
    const char* errNeedAuth            = 
                "ERROR: Connection requires LRWP2 authentication";
    const char* errExcluded            = "ERROR: Application not permitted";
    const char* errComponentTooLong    = 
                "ERROR: Registration component too long";
    tcb = thread->tcb;                 /*  Point to thread's context         */

    /* Read in peer connection string */
    /* NOTE: We assume that this arrives in a single packet, which may       */
    /* be a somewhat dangerous assumption given its length.                  */
    
    /* LRWP connection request contains:
     *   LRWP 1.0: applicationname 0xFF virtualhostname 0xFF filterext [0xFF]
     *   LRWP 2.0: 0xFF proto_major "." proto_minor 0xFF applicationname
     *             0xFF virtualhostname 0xFF
     *
     * We detect the protocol version by the initial 0xFF character (2.0 or
     * higher).
     */
    num = read_TCP(tcb->handle, buff, LRWP_MAXSTARTUP);
    if (num < LRWP_MAXSTARTUP)             /* make sure it is NUL terminated */
        *(buff+num) = '\0';         
    else
        *(buff+LRWP_MAXSTARTUP-1) = '\0';

    /* Determine version of peer LRWP protocol */
    if (*buff == delim) {
        /* LRWP 2.0 or higher: parse version number: x.y
         * NOTE: assumes numbers are sequential in character set, which
         * is safe for all character sets I'm currently aware of (EDM)
         */
        if (isdigit(buff[1]) && buff[2] == '.' && isdigit(buff[3]) &&
            buff[4] == delim) {
            proto_major = (buff[1] - '0');
            proto_minor = (buff[3] - '0');
        }
        else {
            tcb->startupError = errLRWP1Malformed;
            the_next_event = startup_error_event;
            return;
        }
    }
    else {
        /* LRWP 1.0, by default */
        proto_major = 1; 
        proto_minor = 0;
    }

    /* parse out the components of the startup string, depending on version  */

    /* NOTE: If start up string changes, major version of protocol should  
     * change; so we assume that we can parse if major version matches.
     */
    if (proto_major == 2) {
        /* parse: 0xFF proto_major "." proto_minor 0xFF applicationname
         *        0xFF virtualhostname 0xFF
         */
        char *lastdelim = NULL;        /*  Position of last deliminter       */

        ASSERT (vhost == NULL && filterExt == NULL);

        appName = buff + 5;            /*  Assumes 0xFF x "." y 0xFF         */

        vhost = strchr(appName, delim);
        if (vhost != NULL) {
            *(vhost++) = '\0';

            /* Eliminate the last delimiter, if present                      */
            lastdelim = strchr(vhost, delim);
            if (lastdelim != NULL)
                *lastdelim = '\0';
        }

        /*  Reject malformed connection strings.  All deliminators
         *  should be present and accounted for.
         */
        if (appName == NULL || strlen(appName) <= 0 ||
            vhost   == NULL || lastdelim       == NULL) {

            tcb-> startupError   = errLRWP2Malformed;
            the_next_event = startup_error_event;
            return;
        }
    }
    else if (proto_major == 1) {
        /* parse: applicationname 0xFF virtualhostname 0xFF filterext [0xFF] */
        appName = buff;
        ASSERT (vhost == NULL && filterExt == NULL);

        vhost = strchr(appName, delim);
        if (vhost != NULL) {
            *(vhost++) = '\0';

            filterExt = strchr(vhost, delim);
            if (filterExt != NULL) {
                char *lastdelim;

                *(filterExt++) = '\0';

                /* Eliminate the last delimiter, if present                  */
                lastdelim = strchr(filterExt, delim);
                if (lastdelim != NULL)
                    lastdelim = '\0';
            } 
        }

        if (appName == NULL || vhost == NULL || filterExt == NULL) {
                /* If parsing failed, send back an error message */
                tcb-> startupError   = errLRWP1Malformed;
                the_next_event = startup_error_event;
                return;
        }
    }
    else {
        /* Unrecognised version number -- send rejection message             */
        tcb-> startupError   = errUnrecognisedVersion;
        the_next_event = startup_error_event;
        return;
    }

    /* Tidy up registration information                                      */
    if (*appName == '/')
        appName++;

    /* Validate length of components (required to avoid overflows later)     */
    if ((appName && strlen(appName) > MAX_APPNAME_LEN)
    ||  (vhost   && strlen(vhost)   > MAX_VHOST_LEN)) {
        tcb-> startupError = errComponentTooLong;
        the_next_event = startup_error_event;
        return;
    }

    /* If we reach here, we have a properly formed LRWP connection
     * request from a LRWP peer that suits the proto_major protocol.
     */

    /* Copy registration information into LRWP TCB for future reference      */
    /* NOTE: Application name can either be a path, in which case it is
     * matched as a prefix; or it can be a ".ext" in which case it is
     * matched as an extension suffix.
     */
    tcb->appName     = mem_strdup(appName);
    tcb->vhost       = mem_strdup(*vhost ? vhost : VHOST_ANY);
    tcb->filterExt   = mem_strdup(filterExt);
    tcb->proto_major = proto_major;
    tcb->proto_minor = proto_minor;

    /* make sure connection is allowed: check both webmask, and per
     * application authentication.
     */
    webmask = http_webmask (http_config (config, "lrwp:webmask"), tcb-> handle);
    if (!socket_is_permitted(socket_peeraddr(tcb->handle), webmask)) {
        tcb-> startupError = errUnauthorised;
        the_next_event = startup_error_event;
        return;
    }

    access = http_config(config, "lrwp:allow-all");
    if (access != NULL && *access == '1') {
        the_next_event = peer_accepted_event;
        return;
    }
    else {
        /*  Not all LRWP connections are allowed; need specific permission   */
        /*  Which means a LRWP-Application: entry for the application name.
         *  If the value is "*" then the application is allowed without
         *  any further authentication.  Otherwise it is used as the
         *  basis of a challenge to the application (LRWP 2.0 or higher).  
         *  LRWP 1.0 connections can handle only the "*" form; if we
         *  don't find a "*" then we reject the application in LRWP 1.0.
         */
        access = http_config(config, makeLRWPAppKey(appName));

        if (access != NULL && *access != '\0') {
            if (streq(access, "*")) {
                the_next_event = peer_accepted_event;
                return;
            }
            else if (proto_major >= 2) {
                the_next_event = challenge_peer_event;
                return;
            }
            else {
                tcb-> startupError = errNeedAuth;
                the_next_event = startup_error_event;
                return;
            }
        }
        else {
            tcb-> startupError = errExcluded;
            the_next_event = startup_error_event;
            return;
        }
    }

    /* Unreachable */
    ASSERT (FALSE);
}

/*****************************   REGISTER PEER   *****************************/

MODULE register_peer (THREAD *thread)
{
    char*       key;
    PTCB*       ptcb;
    RTRData*    rtr;
    SYMBOL*     rtrSym;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    /* create the table if this is the first peer. */
    if (!peerTable)
        peerTable = sym_create_table();

    /* find or create the router symbol in the peer symbol table*/
    key = makeTableKey(tcb->appName, tcb->vhost);
    rtrSym = sym_lookup_symbol(peerTable, key);
    if (! rtrSym) {
        rtrSym = sym_create_symbol(peerTable, key, NULL);
        rtrSym->data = mem_alloc(sizeof(RTRData));
        rtr = rtrSym->data;
        rtr->name  = mem_strdup(tcb->appName);
        rtr->vhost = mem_strdup(tcb->vhost);
        node_reset(&rtr->peerList);
        node_reset(&rtr->waitingRequests);

        send_wsx_install(&http_thread->queue->qid,
                        tcb->vhost,
                        tcb->appName,
                        LRWP_NAME);
    }
    rtr = rtrSym->data;

    /* tell the router about this thread */
    ptcb = node_create(&rtr->peerList, sizeof(PTCB));
    ptcb->thread = thread;
    ptcb->busy = 0;

    /* give this thread a pointer to the peer thread control block */
    tcb->ptcb = ptcb;
    tcb->rtr = rtr;

    /* Log peer connection */
    sendfmt(&operq, "INFO",
            LRWP_NAME ": Peer %s connected for %s host",
                tcb->rtr->name, tcb->rtr->vhost);
}

/***********************   SEND PEER ACKNOWLEDGEMENT   ***********************/

MODULE send_peer_acknowledgement (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */

    if (tcb->proto_major == 1) 
        write_TCP(tcb->handle, "OK", 2);                   /* LRWP 1.0       */
    else 
        write_TCP(tcb->handle, "OK" LRWP_STRING_DELIM, 3); /* LRWP >= 2.0    */
}


/********************   SEND PEER NEGOTIATION CHALLENGE   ********************/

MODULE send_peer_negotiation_challenge (THREAD *thread)
{
    char sizebuf[LENGTH_LEN + 1];
    int  i;

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    write_TCP(tcb->handle, "CHALLENGE" LRWP_STRING_DELIM, 10);

    /* Generate challenge string, using high order bits of rand() value
     * which are generally "more random" (see Linux rand() man page, and
     * its sources "Numerical References in C" and Knuth TAOCP vol 2).
     */
    for (i = 0; i < CHALLENGE_LENGTH; i++)
         tcb->challenge[i] = (byte)((256.0 * rand())/(RAND_MAX*1.0));

    sprintf(sizebuf, LENGTH_FORMAT, CHALLENGE_LENGTH);

    write_TCP(tcb->handle, sizebuf, LENGTH_LEN); 
    write_TCP(tcb->handle, tcb->challenge, CHALLENGE_LENGTH);

    /* Prepare to receive response to challenge                              */
    if (tcb->buffer)
        mem_free(tcb->buffer);
    tcb->numtoread   = 0;
    tcb->numread     = 0;
    *(tcb->sizebuff) = '\0';
}


/*********************   CHECK PEER NEGOTATION RESPONSE   ********************/

/* Check challenge response from peer (stored in tcb buffers)                */
MODULE check_peer_negotiation_response (THREAD *thread)
{
    char *accessKey;
    byte *challengeResponse;
    int  i, accessKeyLen;

    const char *errWrongResponse = "Incorrect LRWP challenge response";

    tcb = thread-> tcb;                 /*  Point to thread's context        */

    ASSERT(tcb->buffer);

    if (tcb->numtoread != CHALLENGE_LENGTH) {
        tcb->startupError = errWrongResponse;
        the_next_event = startup_error_event;
    }
    else {
        accessKey = http_config(config, makeLRWPAppKey(tcb->appName));
        ASSERT (accessKey);
        accessKeyLen = strlen(accessKey);

        /* Validate challenge response */
        the_next_event = peer_accepted_event;

        for (i = 0, challengeResponse = (byte *)tcb->buffer;
             i < CHALLENGE_LENGTH; 
             i++, challengeResponse++) 

             if (*challengeResponse !=
                     (((tcb->challenge)[i]) ^ (accessKey[i % accessKeyLen]))) 
                 the_next_event = startup_error_event;

        if (the_next_event == startup_error_event) 
                 tcb-> startupError = errWrongResponse;
    }

    mem_free(tcb->buffer);
    tcb->numtoread   = 0;
    tcb->numread     = 0;
    *(tcb->sizebuff) = '\0';
}


/***********************   SEND REQUEST DATA TO PEER   ***********************/

MODULE send_request_data_to_peer (THREAD *thread)
{
    REQ     req;
    char    sizebuf[LENGTH_LEN + 1];
    long    size;

    tcb = thread->tcb;

    /*  We copy the thread body to a REQ structure to avoid alignment errors
     *  which can arise on some systems if we try to use the thread body as
     *  a REQ structure directly (it is byte aligned)
     */
    memcpy (&req, thread-> event-> body, sizeof (REQ));
    tcb-> replyQ = req.replyQ;

    /*  **** Should set and handle timeout on these... */
    /*  send the size as a zero-filled field, followed by the env data */
    sprintf(sizebuf, LENGTH_FORMAT, req.wsxreq->symbols_size);
    send_write(&sockq, 0, tcb->handle, 9, (byte*)sizebuf, 0);
    send_write(&sockq, 0, tcb->handle, req.wsxreq->symbols_size,
                        req.wsxreq->symbols_data, 0);

    /* The post data goes the same way; may either be in a file or in 
     * a buffer.  Depends largely on size of incoming data.  In file if
     * buffer contains @filename
     */
    if (req.wsxreq->post_data[0] == '@') {
        /* Send the file... */
        size = get_file_size(req.wsxreq->post_data+1);
        sprintf(sizebuf, LENGTH_FORMAT_LONG, size);
        send_write(&sockq, 0, tcb->handle, 9, (byte*)sizebuf, 0);
        if (size)
            send_put_file (&tranq, tcb-> handle, req.wsxreq-> post_data + 1,
                           0, 0, 0, NULL);
    }
    else {
        /* Send the buffer */
        sprintf(sizebuf, LENGTH_FORMAT_LONG, 
                size = strlen(req.wsxreq->post_data));
        send_write(&sockq, 0, tcb->handle, 9, (byte*)sizebuf, 0);
        if (size)
            send_write(&sockq, 0, tcb->handle, (word)size,
                       (byte*)req.wsxreq->post_data, 0);
    }

    /* free the request data */
    free_smt_wsx_request (&req.wsxreq);

    /* clear incoming length string ready for the return data */
    tcb-> sizebuff[0] = '\0';
}



/***************************   READ PEER DATA SIZE  **************************/

MODULE read_peer_data_size (THREAD *thread)
{
    int     len;

    tcb = thread->tcb;

    /* XXX: Assumes will arrive in one packet */
    len = read_TCP(tcb->handle, tcb->sizebuff, LENGTH_LEN);
    if (len != LENGTH_LEN) {
        trace(LRWP_NAME ": read_peer_data **** did not read full size!");
        tcb->sockError = mem_strdup(sockmsg());
        raise_exception(sock_error_event);
        return;
    }
    tcb->sizebuff[len] = '\0';          /* NUL terminate it */
    tcb->numtoread = atoi(tcb->sizebuff);
    tcb->numread = 0;
    tcb->buffer = mem_alloc(tcb->numtoread+1);
}


/*****************************   READ PEER DATA   ****************************/

MODULE read_peer_data (THREAD *thread)
{
    int     len;
    tcb = thread->tcb;
   
    len = read_TCP(tcb->handle, tcb->buffer+tcb->numread,
                                tcb->numtoread-tcb->numread);
    if (len == SOCKET_ERROR) {
        if (sockerrno == EAGAIN || sockerrno == EWOULDBLOCK)
            return;
        else
        if (sockerrno == EPIPE || sockerrno == ECONNRESET) {
            the_next_event = sock_closed_event;
            return;
        }
        else {
            tcb->sockError = mem_strdup(sockmsg());
            raise_exception(sock_error_event);
            return;
        }
    }

    tcb->numread += len;
    if (tcb->numread == tcb->numtoread) {
        the_next_event = finished_event;
        tcb->buffer[tcb->numread] = '\0';
    }
}

/************************   SEND PEER DATA TO XITAMI   ***********************/

MODULE send_peer_data_to_xitami (THREAD *thread)
{
    static unsigned short   count = 0;
    char                    filename[16];
    int                     hdl;
    int                     err;

    tcb = thread->tcb;

    /* Return data sent directly in buffer to LRWP peer, unless it
     * happens to begin with "@" which would confuse the auto-detection
     * of "is in file", or it is very big and would take lots of memory,
     * in which case we send it as a file.  This saves writing it out 
     * to disk unless we need to do so.
     * XXX: We should possibly write big returns out to disk immediately.
     * XXX: Debugging?  Should we save to disk in debug mode?
     */
    if (*tcb->buffer == '@' || tcb->numread > BIG_RESPONSE_LEN) {
        /* Write return data out to a file, and then pass to caller          */
        /* XXX: snprintf() */
        sprintf(filename, "@lrwp%05d.tmp", ++count);

        /* XXX: O_EXCL? */
        hdl = open(filename+1, O_CREAT | O_BINARY | O_RDWR, 0666);
        err = write(hdl, tcb->buffer, tcb->numread);
        err = close(hdl);
        send_wsx_ok(&tcb->replyQ, filename);
    }
    else 
        /* Pass return data in memory to caller                              */
        send_wsx_ok(&tcb->replyQ, tcb->buffer);
}


/***********************   CLEANUP AND INFORM ROUTER   ***********************/

MODULE cleanup_and_inform_router (THREAD *thread)
{
    tcb = thread-> tcb;
    tcb->ptcb->busy = FALSE;
    *tcb->sizebuff = 0;
    tcb->numtoread = 0;
    tcb->numread = 0;
    mem_free(tcb->buffer);

    SEND(&rtrThread->queue->qid, LRWP_JOBCOMP,
            makeTableKey(tcb->rtr->name, tcb->rtr->vhost));
}



/***************************   SIGNAL PEER CLOSED   **************************/

MODULE signal_peer_closed (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */
    sendfmt(&operq, "INFO",
            LRWP_NAME ": App %s on %s terminating",
            tcb->rtr->name, tcb->rtr->vhost);
}

/***************************   SIGNAL STARTUP ERROR   *************************/

MODULE signal_startup_error (THREAD *thread)
{
    tcb = thread->tcb;                 /*  Point to thread's context         */

    /*  Log error message */
    sendfmt(&operq, "INFO",
            LRWP_NAME ": Peer %s failed to connect (%s)", 
            (tcb->appName ? tcb->appName : ""), tcb->startupError);

    /*  And send it out to the peer */
    sendPeerErrorMessage(tcb->handle, tcb->startupError, tcb->proto_major);
}

static void  sendPeerErrorMessage(int handle, const char *errorMessage, 
                                  int lrwpVer)
{
    /* Assumes that everything can be written at once, and that LRWP 2+
     * clients will properly parse buffer for full message, rather than
     * relying on it being sent all at once.
     */
    if (lrwpVer > 1)
        write_TCP(handle, "REJECTED" LRWP_STRING_DELIM, 9);

    write_TCP(handle, errorMessage, strlen(errorMessage));

    if (lrwpVer > 1)
        write_TCP(handle, LRWP_STRING_DELIM, 1);

}

/****************************   SEND ERROR REPLY   ***************************/

MODULE send_error_reply (THREAD *thread)
{
    tcb = thread-> tcb;                 /*  Point to thread's context        */
    send_wsx_error(&tcb->replyQ, HTTP_RESPONSE_INTERNALERROR);
}


/**************************   FIND AVAILABLE PEER   **************************/

static Bool send_to_unbusy_peer(THREAD* thread, RTRData* rtr, REQ* req)
{
    PTCB*    ptcb;

    /* fprintf(stderr, "Searching for free peer: "); */
    for (ptcb=rtr->peerList.next;
        (NODE*)ptcb != &rtr->peerList;
        ptcb=ptcb->next) {
        /*fprintf(stderr, "%ld:%d ", (long)ptcb, ptcb->busy); */
        if (! ptcb->busy) {
            event_send(&ptcb->thread->queue->qid,   /* To                    */
                &thread->queue->qid,                /* From                  */
                LRWP_REQUEST,                       /* Event name            */
                (byte*)req, sizeof(REQ),            /* The message           */
                NULL, NULL, NULL, 0);

                /* free the req, but not its contents. */
            node_destroy(req);
            ptcb->busy = TRUE;

            /* fprintf(stderr, "Found! \n"); */
            return TRUE;
        }
    }
    /* fprintf(stderr, "None!\n"); */
    return FALSE;
}

/* Determine which (if any) of the peers matches the URI we are given        */
/* This handles prefix matches and extension matches.                        */
static RTRData* lrwp_match_peer(char* uri, char* vhost)
{
    SYMBOL*     symbol;
    RTRData*    rtr;
    int         urilen, namelen;

    if (*uri == '/')
        uri++;

    urilen = strlen(uri);                     /* XXX: Allow for ?... bits?   */

    symbol = peerTable->symbols;
    for (symbol = peerTable->symbols; symbol != NULL; symbol = symbol->next) {
        rtr = symbol->data;
        if (streq(vhost, rtr->vhost) || streq(VHOST_ANY, rtr->vhost)) {

            if (*rtr->name == '.') {                   /*  Match extension   */
                namelen = strlen(rtr->name);

                if (urilen > namelen &&
                    streq((uri+(urilen-namelen)), rtr->name))
                    return rtr;
            }
            else if (strprefixed(uri, rtr->name))     /*  Match prefix       */
                return rtr;
        }
    }
    return NULL;
}


MODULE find_available_peer (THREAD *thread)
{
    REQ*        req;
    WSXREQ*     wsxreq;
    RTRData*    rtr;


    tcb = thread->tcb;                 /*  Point to thread's context         */

    /*  Decode the WSX request          */
    get_smt_wsx_request(thread->event->body, &wsxreq);
    if (!wsxreq) {
        /*  The request can only be null if there is no memory left          */
        send_wsx_error(&thread->event->sender, HTTP_RESPONSE_OVERLOADED);
        the_next_event = exception_event;
        return;
    }

    req = node_create(NULL, sizeof(REQ));
    req->replyQ = thread->event->sender;
    req->wsxreq = wsxreq;

        /*
         * find peerData that matches the vhost and the leading portion of the
         * wsxreq->request_url
         */
    rtr = lrwp_match_peer(wsxreq->request_url, wsxreq->virtual_host);
    if (!rtr) {
        send_wsx_error(&req->replyQ, HTTP_RESPONSE_NOTFOUND);
        mem_free(req);
        free_smt_wsx_request (&wsxreq);
        return;
    }


        /* send request to available peer */
    if (! send_to_unbusy_peer(thread, rtr, req)) {
            /* if none available, save the request for later */
        node_relink_before(req, &rtr->waitingRequests);
    }
}

/************************   CHECK FOR SAVED REQUESTS   ***********************/

MODULE check_for_saved_requests (THREAD *thread)
{
    REQ*        req;
    char*       key;
    SYMBOL*     rtrSym;
    RTRData*    rtr;

    tcb = thread->tcb;
    key = (char*)thread->event->body;
    rtrSym = sym_lookup_symbol(peerTable, key);
    if (rtrSym) {
        rtr = rtrSym->data;
        if (rtr->waitingRequests.next
        && (rtr->waitingRequests.next != (void*)&rtr->waitingRequests)) {
            req = rtr->waitingRequests.next;
            node_unlink(req);
                /* send request to available peer */
            if (! send_to_unbusy_peer(thread, rtr, req)) {
                /* if none available, put the request back at the
                   head of the list */
                node_relink_after(req, &rtr->waitingRequests);
            }
        }
    }
}


/***************************   CHECK IF ALL GONE   ***************************/

MODULE check_if_all_gone (THREAD *thread)
{
    REQ*        req;
    char*       key;
    SYMBOL*     rtrSym;
    RTRData*    rtr;

    tcb = thread->tcb;                 /*  Point to thread's context         */

    /* if the peer list is empty, cleanup. */
    key = (char*)thread->event->body;

    /* Lookup the main webserver thread again.  We may already have this
     * value, but during shutdown the thread may be gone, in which case
     * we don't want to try to send it messages.
     */
    http_thread = thread_lookup (SMT_HTTP, "main");

    /*  PH 98/07/14: peerTable could be NULL at this point                   */
    rtrSym = peerTable? sym_lookup_symbol(peerTable, key): NULL;
    if (rtrSym) {
        rtr = rtrSym->data;
        if (rtr->peerList.next == (void*)&rtr->peerList) {
            /* first clean up the waitingRequests list. */
            while (rtr->waitingRequests.next != (void*)&rtr->waitingRequests) {
                req = rtr->waitingRequests.next;
                node_unlink(req);
                send_wsx_error(&req->replyQ, HTTP_RESPONSE_NOTIMPLEMENTED);
                mem_free(req);
                free_smt_wsx_request (&req->wsxreq);
            }

            /* Remove this alias from Xitami, if HTTP thread still around    */
            if (http_thread)
                send_wsx_cancel(&http_thread->queue->qid,
                                (streq(rtr->vhost, VHOST_ANY) 
                                       ? NULL : rtr->vhost),
                                rtr->name);

            /* Then remove this thing from the peerTable */
            mem_free(rtr->name);
            mem_free(rtr->vhost);
            mem_free(rtrSym->data);
            sym_delete_symbol(peerTable, rtrSym);

            /* if the table is empty, get rid of it. */
            if (peerTable->size == 0) {
                sym_delete_table(peerTable);
                peerTable = NULL;
                if (tcb->termWhenEmpty)
                    the_next_event = terminate_event;
            }
        }
    }
}

