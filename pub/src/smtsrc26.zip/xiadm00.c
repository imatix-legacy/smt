/*  --------------------------- N O T I C E ------------------------------
    This file has been stripped of symbolic information in order to protect
    trade secrets and protected and/or confidential source code.  This file
    remains Copyright (c) 1997 iMatix and is subject to the following terms
    and conditions in addition to the license terms agreed-on between the
    user and iMatix:
    1.  All reverse-engineering, reconstruction, or partial reuse of this
        source code is forbidden.
    2.  Any modification of this source code will consitute a violation of
        the license and guarantee terms agreed between the user and iMatix.
    3.  Distribution of this source code is allowed only according to the
        terms of the respective product license agreement.
    ---------------------------------------------------------------------- */
#include "sfl.h"
#include "formio.h"
char
*form_strerror;
RANGE
range_all = { 0, -1 },
range_none = { -1, 0 };
static FORM_ITEM
*_2892;
static SYMTAB
*_2893;
static int
_2894;
enum {
_2895 = 1,
focus_field = 2,
_2896 = 3
};
static char
*_2897 = "<TABLE><TR><TD BGCOLOR=\"#FF0000\">&gt;",
*_2898 = "</TABLE>";
static FORM_ITEM *_2899 (FORM_DEFN *defn);
static char *_2900 (byte *_2901);
static void _2902 (VDESCR *stream, byte *block, int field, int _2903);
static void _2904 (VDESCR *stream, char *source, int size);
static void _2905 (VDESCR *stream, char *source);
static void _2906 (VDESCR *stream, char *format, ...);
static void _2907 (VDESCR *stream, byte *block);
static void _2908 (VDESCR *stream, byte *block);
static void _2909 (VDESCR *stream, byte *block, int field, int _2903);
static void _2910 (VDESCR *stream, byte *block, int field, int _2903);
static void _2911 (VDESCR *stream, byte *block, int field, int _2903);
static void _2912 (VDESCR *stream, byte *block, int field, int _2903);
static void _2913 (VDESCR *stream, byte *block, int field, int _2903);
static void _2914 (VDESCR *stream, byte *block, int field, int _2903);
static void _2915 (VDESCR *stream, byte *block, int field, int _2903);
static void _2916 (VDESCR *stream, byte *block, int field, int _2903);
static void _2917 (VDESCR *stream, byte *block, int index);
static void _2918 (VDESCR *stream, byte *block);
static void _2919 (VDESCR *stream, char *value, int field, int _2903);
static void _2920 (byte *block, int field, int index, byte attr);
static Bool _2921 (int field);
static Bool _2922 (int field, int index);
static Bool _2923 (RANGE *range, int field);
static byte *_2924 (int field, int index);
static char *_2925 (int field, int index);
static char *_2926 (byte *block, int index);
static void _2927 (byte *block, int *flags, int *_2928, int *_2929,
int *width);
static int _2930 (byte *block, int field, int index, char *value);
static void _2931 (int field, int index);
static int _2932 (byte *block, int field, int index, char *value);
static int _2933 (byte *block, int field, int index, char *value);
static int _2934 (byte *block, int field, int index, char *value);
static int _2935 (byte *block, int field, int index, char *value);
static void _2936 (SYMTAB *symtab, byte *block);
static Bool _2937 (char *value);
static char *_2938 (int field, int index, int item, char _2939);
static char *_2940 (int field, int index, int item, char _2939);
static Bool _2941 (FORM_ITEM *form, byte *_2901,
int _2942, va_list _2943);
static Bool _2944 (FORM_ITEM *form, byte *_2901,
int _2942, va_list _2943);
static Bool _2945 (FORM_ITEM *form, byte *_2901,
int _2942, va_list _2943);
static Bool _2946 (FORM_ITEM *form, byte *_2901,
int _2942, va_list _2943);
static Bool _2947 (SYMBOL *symbol, ...);
static void _2948 (SYMTAB *symtab);
#define _2949(b) ((b) [0] << 8) + ((b) [1])
#define _2950(b) ((b) [2])
#define _2951(b) ((b) [3])
#define _2952(b) ((b) [4])
#define _2953(b) ((char *) ((b) + 3))
#define _2954(b) ((b) [3])
#define _2955(b) ((b) [4] << 8) + ((b) [5])
#define _2956(b) ((b) [6] << 8) + ((b) [7])
#define _2957(b) ((b) [3] << 8) + ((b) [4])
#define _2958(b) ((b) [5] << 8) + ((b) [6])
#define _2959(b) ((b) [3] << 8) + ((b) [4])
#define _2960(b) ((b) [5] << 8) + ((b) [6])
#define _2961(b) ((b) [3] << 8) + ((b) [4])
#define _2962(b) ((b) [5] << 8) + ((b) [6])
#define _2963(b) ((b) [7] << 8) + ((b) [8])
#define _2964(b) ((b) [3])
#define _2965(b) ((b) [4])
#define _2966(b) ((b) [5])
#define _2967(b) ((b) [6] << 8) + ((b) [7])
#define _2968(b) ((b) [8] << 8) + ((b) [9])
#define _2969(b) ((char *) ((b) + 10))
#define _2970(b) (_2969 (b) + strlen (_2969 (b)) + 1)
#define _2971(b) ((b) [3])
#define _2972(b) ((b) [4])
#define _2973(b) ((b) [5] << 8) + ((b) [6])
#define _2974(b) ((b) [7] << 8) + ((b) [8])
#define _2975(b) ((char *) ((b) + 9))
#define _2976(b) (_2975 (b) + strlen (_2975 (b)) + 1)
#define _2977(b) ((b) [3])
#define _2978(b) ((b) [4])
#define _2979(b) ((b) [5] << 8) + ((b) [6])
#define _2980(b) ((b) [7] << 8) + ((b) [8])
#define _2981(b) ((b) [9])
#define _2982(b) ((b) [10])
#define _2983(b) ((b) [11])
#define _2984(b) ((b) [12])
#define _2985(b) ((b) [13])
#define _2986(b) ((b) [14])
#define _2987(b) ((char *) ((b) + 15))
#define _2988(b) (_2987 (b) + strlen (_2987 (b)) + 1)
#define _2989(b) ((b) [3])
#define _2990(b) ((b) [4])
#define _2991(b) ((b) [5] << 8) + ((b) [6])
#define _2992(b) ((b) [7])
#define _2993(b) ((b) [8])
#define _2994(b) ((b) [9])
#define _2995(b) ((b) [10])
#define _2996(b) ((b) [11])
#define _2997(b) (char *) ((b) + 12)
#define _2998(b) (_2997 (b) + strlen (_2997 (b)) + 1)
#define _2999(b) (_2998 (b) + strlen (_2998 (b)) + 1)
#define _3000(b) ((b) [3])
#define _3001(b) ((b) [4])
#define _3002(b) ((b) [5])
#define _3003(b) ((b) [6])
#define _3004(b) ((b) [7])
#define _3005(b) ((b) [8] << 8) + ((b) [9])
#define _3006(b) ((char *) ((b) + 10))
#define _3007(b) (_3006 (b) + strlen (_3006 (b)) + 1)
#define _3008(b) ((b) [3])
#define _3009(b) ((b) [4])
#define _3010(b) ((char *) ((b) + 5))
#define _3011(b) (_3010 (b) + strlen (_3010 (b)) + 1)
#define _3012(b) (_3011 (b) + strlen (_3011 (b)) + 1)
#define _3013(b) (_3012 (b) + strlen (_3012 (b)) + 1)
#define _3014(b) ((b) [3])
#define _3015(b) ((b) [4])
#define _3016(b) ((b) [5])
#define _3017(b) ((b) [6])
#define _3018(b) ((char *) ((b) + 7))
#define _3019(b) (_3018 (b) + strlen (_3018 (b)) + 1)
#define _3020(b) (_3019 (b) + strlen (_3019 (b)) + 1)
#define _3021(b) (_3020 (b) + strlen (_3020 (b)) + 1)
#define _3022(b) ((b) [3])
#define _3023(b) ((b) [4])
#define _3024(b) ((b) [5])
#define _3025(b) ((b) [6])
#define _3026(b) ((char *) ((b) + 7))
#define _3027(b) (_3026 (b) + strlen (_3026 (b)) + 1)
#define _3028(b) (_3027 (b) + strlen (_3027 (b)) + 1)
#define _3029(b) ((b) [3] << 8) + ((b) [4])
#define _3030(b) ((b) [5])
#define _3031(b) ((char *) ((b) + 6))
#define _3032(b) ((b) [3])
#define _3033(b) ((b) [4] << 8) + ((b) [5])
#define _3034(b) ((b) [6] << 8) + ((b) [7])
#define _3035(b) ((b) [8])
#define _3036(b) ((b) [9] << 8) + ((b) [10])
#define _3037(b) ((b) [11] << 8) + ((b) [12])
#define _3038(b) ((char *) ((b) + 13))
#define _3039(b) (_3038 (b) + strlen (_3038 (b)) + 1)
#define _3040(t) ((t) == BLOCK_TEXTUAL || \
(t) == BLOCK_NUMERIC || \
(t) == BLOCK_DATE || \
(t) == BLOCK_TEXTBOX || \
(t) == BLOCK_BOOLEAN || \
(t) == BLOCK_SELECT || \
(t) == BLOCK_FILE || \
(t) == BLOCK_RADIO )
#define _3041(f) ((char *) _2892-> data + \
_2892-> defn-> fields [f].data)
#define _3042(f) (_2892-> defn-> blocks + \
_2892-> defn-> fields [f].block)
#define _3043(f) (_2892-> defn-> fields [f].max)
#define _3044(b) (_2892-> data + \
_2892-> defn-> fields_size + _3034 (b))
#define _3045 1
typedef struct {
char *input;
char *output;
int _3046;
int _3047;
} _3048;
static _3048 _3049 [] = {
{ "TEXT", "%s",                 0, 0 },
{ "TEXT", "%s",                 1, 0 },
{ "PASSWORD", "",               0, 0 },
{  NULL,  "%s",                 0, 0 },
{ "HIDDEN", "",                 0, 1 },
{  NULL,  "",                   0, 1 },
{  NULL, "%s",                  0, 0 },
{  NULL, "<EM>%s</EM>",         0, 0 },
{  NULL, "<STRONG>%s</STRONG>", 0, 0 },
{  NULL, "<BIG>%s</BIG>",       0, 0 },
{  NULL, "%s",                  0, 0 }
};
FORM_ITEM *
form_init (
FORM_DEFN *defn,
Bool values)
{
FORM_ITEM
*form;
ASSERT (defn);
if ((form = _2899 (defn)) == NULL)
return (NULL);
if (values)
{
form-> language = FLANG_ENGLISH;
form-> date_order = DATE_ORDER_DMY;
form-> date_sep = '/';
form-> dec_point = '.';
form-> input_range = range_all;
form-> blank_range = range_none;
form-> JavaScript = 1;
form-> focus_field = 0;
form-> focus_index = 0;
form-> click_field = 0;
form-> click_index = 0;
form_use (form);
form_exec (form, _2941);
}
return (form);
}
static FORM_ITEM *
_2899 (
FORM_DEFN *defn)
{
FORM_ITEM
*form;
MEMTRN
*_3050;
ASSERT (defn);
_3050 = mem_new_trans ();
if ((form = mem_alloc (sizeof (FORM_ITEM))) == NULL)
return (NULL);
memset (form, 0, sizeof (FORM_ITEM));
form-> defn = defn;
form-> data_size = defn-> fields_size + defn-> action_count;
form-> data = mem_alloc (form-> data_size);
if (form-> data == NULL)
{
mem_rollback (_3050);
return (NULL);
}
memset (form-> data, 0, form-> data_size);
mem_commit (_3050);
return (form);
}
static Bool
_2941 (
FORM_ITEM *form,
byte *_2901,
int _2942,
va_list _2943)
{
byte
_3051,
_3052;
char
*_3053,
*_3054;
int
_3055;
if (_3040 (_2950 (_2901)))
{
_3051 = _2952 (_2901);
_3052 = _2951 (_2901);
_3054 = _2900 (_2901);
_3053 = _3041 (_2942);
for (_3055 = 0; _3055 < _3051; _3055++)
*_3053++ = _3052;
ASSERT (strlen (_3054) <= _3043 (_2942));
for (_3055 = 0; _3055 < _3051; _3055++)
{
strcpy ((char *) _3053, _3054);
_3053 += _3043 (_2942) + 1;
}
}
else
if (_2950 (_2901) == BLOCK_ACTION)
*_3044 (_2901) = _3035 (_2901);
return (TRUE);
}
static char *
_2900 (byte *_2901)
{
switch (_2950 (_2901))
{
case BLOCK_TEXTUAL: return (_2970 (_2901));
case BLOCK_FILE: return (_2976 (_2901));
case BLOCK_NUMERIC: return (_2988 (_2901));
case BLOCK_DATE: return (_2998 (_2901));
case BLOCK_TEXTBOX: return (_3007 (_2901));
case BLOCK_BOOLEAN: return (_3011 (_2901));
case BLOCK_SELECT: return (_3019 (_2901));
case BLOCK_RADIO: return (_3027 (_2901));
}
return (NULL);
}
void
form_term (
FORM_ITEM *form)
{
if (form)
{
if (form-> list_values)
sym_delete_table (form-> list_values);
mem_free (form-> data);
mem_free (form);
}
}
void
form_use (
FORM_ITEM *form)
{
ASSERT (form);
_2892 = form;
}
size_t
form_put (
FORM_ITEM *form,
VDESCR *stream,
SYMTAB *symtab)
{
byte
*_2901,
_3056,
*_3057;
int
_2942,
_3058,
_3059,
_3060,
_3061,
_3062,
_3063;
ASSERT (form);
ASSERT (stream);
ASSERT (symtab);
stream-> cur_size = 0;
stream-> data = stream-> data;
form-> status = FSTATUS_OK;
_2942 = -1;
_3059 = 0;
_3058 = 0;
_2901 = form-> defn-> blocks;
_2892 = form;
_2893 = symtab;
_2894 = 0;
sym_assume_symbol (symtab, "_focus", "jsaction");
while (_3058 < form-> defn-> block_count)
{
_3056 = _2950 (_2901);
if (_3040 (_3056))
_2942++;
if (_3059 > 0)
_3059--;
else
if (_3056 == BLOCK_IF)
{
if (_2937 (_2925 (_2957 (_2901), 0)))
_3059 = _2958 (_2901);
}
else
if (_3056 == BLOCK_UNLESS)
{
if (!_2937 (_2925 (_2959 (_2901), 0)))
_3059 = _2960 (_2901);
}
else
if (_3056 == BLOCK_REPEAT)
{
_3060 = atoi (_2925 (_2961 (_2901), 0));
for (_3061 = 0; _3061 < _3060; _3061++)
{
_3062 = _2942;
_3057 = _2901;
for (_3063 = 0;
_3063 < _2962 (_2901);
_3063++)
{
_3057 += _2949 (_3057) + 2;
if (_3040 (_2950 (_3057)))
_3062++;
_2902 (stream, _3057, _3062,
_3061);
}
}
_3059 = _2962 (_2901);
}
else
if (!_2921 (_2942))
_2902 (stream, _2901, _2942, 0);
_2901 += _2949 (_2901) + 2;
_3058++;
}
form-> focus_field = 0;
form-> focus_index = 0;
if (stream-> cur_size >= stream-> max_size)
stream-> cur_size = stream-> max_size - 1;
stream-> data [stream-> cur_size] = '\0';
return (stream-> cur_size);
}
static Bool
_2921 (int _2942)
{
return (_2923 (&_2892-> blank_range, _2942));
}
static Bool
_2923 (RANGE *range, int _2942)
{
if (range-> first == -1)
return (FALSE);
else
if (range-> last == -1)
return (TRUE);
else
return (range-> first <= _2942 &&
_2942 <= range-> last);
}
static void
_2902 (
VDESCR *stream,
byte *_2901,
int _2942,
int index)
{
switch (_2950 (_2901))
{
case BLOCK_PLAIN:
_2907 (stream, _2901);
break;
case BLOCK_COMPRESSED:
_2908 (stream, _2901);
break;
case BLOCK_TEXTUAL:
_2909 (stream, _2901, _2942, index);
break;
case BLOCK_FILE:
_2910 (stream, _2901, _2942, index);
break;
case BLOCK_NUMERIC:
_2911 (stream, _2901, _2942, index);
break;
case BLOCK_DATE:
_2912 (stream, _2901, _2942, index);
break;
case BLOCK_TEXTBOX:
_2913 (stream, _2901, _2942, index);
break;
case BLOCK_BOOLEAN:
_2914 (stream, _2901, _2942, index);
break;
case BLOCK_SELECT:
_2915 (stream, _2901, _2942, index);
break;
case BLOCK_RLABEL:
_2916 (stream, _2901, _2942, index);
break;
case BLOCK_ACTION:
_2917 (stream, _2901, index);
break;
}
}
static void
_2907 (VDESCR *stream, byte *_2901)
{
_2904 (stream, _2953 (_2901), _2949 (_2901) - 1);
}
static void
_2904 (VDESCR *stream, char *source, int size)
{
static char
_3064 [FORMIO_SYMNAME_MAX + 1];
char
*_3065,
*_3066,
*_3067;
int
_3068;
while (size > 0 && (_3065 = memchr (source, '#', size)) != NULL)
{
if (_3065 > source)
{
_2904 (stream, source, (int) (_3065 - source));
size -= (int) (_3065 - source);
source = _3065;
}
_3066 = memchr (source, ')', size);
if (source [1] == '(' && _3066)
{
_3068 = (int) (_3066 - source - 2);
if (_3068 <= FORMIO_SYMNAME_MAX)
{
memcpy (_3064, source + 2, _3068);
_3064 [_3068] = '\0';
_3067 = sym_get_value (_2893, _3064, "(?)");
_2904 (stream, _3067, strlen (_3067));
}
else
_2904 (stream, source, (int) (_3066 - source) + 1);
size -= (int) (_3066 - source) + 1;
source = _3066 + 1;
}
else
{
if ((stream-> cur_size + 1) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, 1);
stream-> cur_size += 1;
}
size--;
source++;
}
}
if ((stream-> cur_size + size) < stream-> max_size)
{
memcpy (stream-> data + stream-> cur_size, source, size);
stream-> cur_size += size;
}
}
static void
_2905 (VDESCR *stream, char *source)
{
_2904 (stream, source, strlen (source));
}
static void
_2908 (VDESCR *stream, byte *_2901)
{
byte
*_3069;
word
block_size;
_3069 = _2955 (_2901) + _2892-> defn-> blocks;
if (_2954 (_2901) == COMPR_WHOLEDICT)
block_size = _2949 (_3069) - 1;
else
if (_2954 (_2901) == COMPR_PARTDICT)
block_size = _2956 (_2901);
else
abort ();
_2904 (stream, _2953 (_3069), block_size);
}
static void
_2909 (VDESCR *stream, byte *_2901, int _2942, int index)
{
char
*value;
_3048
*_3070;
byte
attr;
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
value = _2925 (_2942, index);
if (_2966 (_2901) & _3045)
strupc (value);
if (_3070-> input && _2922 (_2942, index))
{
_2920 (_2901, _2942, index, attr);
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3070-> input,
_2926 (_2901, index),
_2967 (_2901),
_2968 (_2901),
attr == FATTR_SECURE? "": value);
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
if (!_3070-> _3047)
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
static void
_2920 (byte *block, int field, int index, byte attr)
{
char
*name;
if ((name = _2926 (block, index)) == NULL)
return;
if (attr == FATTR_ERROR
&& _2894 < _2896)
{
_2894 = _2896;
sym_assume_symbol (_2893, "_focus", name);
}
else
if (field == _2892-> focus_field
&& index == _2892-> focus_index
&& _2894 < focus_field)
{
_2894 = focus_field;
sym_assume_symbol (_2893, "_focus", name);
}
else
if (attr != FATTR_HIDDEN
&& _2894 < _2895)
{
_2894 = _2895;
sym_assume_symbol (_2893, "_focus", name);
}
}
static void
_2910 (VDESCR *stream, byte *_2901, int _2942, int index)
{
char
*_3071,
*value;
_3048
*_3070;
byte
attr;
value = _2925 (_2942, index);
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> input && _2922 (_2942, index))
{
_2920 (_2901, _2942, index, attr);
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<INPUT TYPE=FILE NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_2926 (_2901, index),
_2967 (_2901),
_2968 (_2901),
attr == FATTR_SECURE? "": value);
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (attr == FATTR_OPTION
|| attr == FATTR_LABEL
|| attr == FATTR_HILITE)
{
_3071 = strrchr (value, '/');
if (_3071 == NULL)
_3071 = strrchr (value, '\\');
if (_3071 == NULL)
_3071 = value;
else
_3071++;
_2906 (stream,
"<A HREF=\"%s\">%s</A>", value, _3071);
}
else
if (!_3070-> _3047)
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
static Bool
_2922 (int _2942, int index)
{
if (*_2924 (_2942, index) == FATTR_HIDDEN
|| _2923 (&_2892-> input_range, _2942))
return (TRUE);
else
return (FALSE);
}
static char *
_2926 (byte *_2901, int index)
{
static
char _3072 [LINE_MAX + 8];
switch (_2950 (_2901))
{
case BLOCK_TEXTUAL:
strncpy (_3072, _2969 (_2901), LINE_MAX);
break;
case BLOCK_FILE:
strncpy (_3072, _2975 (_2901), LINE_MAX);
break;
case BLOCK_NUMERIC:
strncpy (_3072, _2987 (_2901), LINE_MAX);
break;
case BLOCK_DATE:
strncpy (_3072, _2997 (_2901), LINE_MAX);
break;
case BLOCK_TEXTBOX:
strncpy (_3072, _3006 (_2901), LINE_MAX);
break;
case BLOCK_BOOLEAN:
strncpy (_3072, _3010 (_2901), LINE_MAX);
break;
case BLOCK_SELECT:
strncpy (_3072, _3018 (_2901), LINE_MAX);
break;
case BLOCK_RADIO:
strncpy (_3072, _3026 (_2901), LINE_MAX);
break;
default:
return (NULL);
}
if (index)
sprintf (_3072 + strlen (_3072), "_%d", index);
return (_3072);
}
static void
_2919 (VDESCR *stream, char *value, int _2942, int index)
{
if (strnull (value))
value = "&lt;Empty&gt;";
if (_2892-> JavaScript)
_2906 (stream,
"<A HREF=\"javascript:submit('~C%d.%d')\">%s</A>\n",
_2942, index, value);
else
_2906 (stream,
"<A HREF=\"#(uri)&~C%d.%d=1\">%s</A>\n",
_2942, index, value);
}
static byte *
_2924 (int _2942, int index)
{
ASSERT (_2942 < _2892-> defn-> field_count);
return (_2892-> data +
_2892-> defn-> fields [_2942].data + index);
}
static char *
_2925 (int _2942, int index)
{
ASSERT (_2942 < _2892-> defn-> field_count);
ASSERT (index < _2952 (_3042 (_2942)));
return (_3041 (_2942)
+ _2952 (_3042 (_2942))
+ (_3043 (_2942) + 1) * index);
}
static Bool
_2937 (char *value)
{
while (*value == '0')
value++;
return (*value == '\0');
}
static void
_2906 (VDESCR *stream, char *format, ...)
{
static char
_3073 [LINE_MAX];
va_list
_2943;
va_start (_2943, format);
#if (defined (DOES_SNPRINTF))
vsnprintf (_3073, LINE_MAX, format, _2943);
#else
vsprintf (_3073, format, _2943);
#endif
va_end (_2943);
_2904 (stream, _3073, strlen (_3073));
}
static void
_2911 (VDESCR *stream, byte *_2901, int _2942, int index)
{
_3048
*_3070;
char
*value;
byte
attr;
int
_3074,
sign_format,
_3075,
_3076;
_2927 (
_2901,
&_3074,
&sign_format,
&_3075,
&_3076);
value = conv_number_str (
_2925 (_2942, index),
_3074,
_2892-> dec_point,
_2981 (_2901),
_3075,
_3076,
sign_format);
if (value == NULL)
value = conv_reason_text [conv_reason];
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> input && _2922 (_2942, index))
{
_2920 (_2901, _2942, index, attr);
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3070-> input,
_2926 (_2901, index),
_2979 (_2901),
_2980 (_2901),
attr == FATTR_SECURE? "": value);
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
if (!_3070-> _3047)
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
static void
_2927 (byte *_2901, int *flags, int *_2928, int *_2929, int *width)
{
*flags = 0;
switch (_2982 (_2901))
{
case FSIGN_NONE:
*_2928 = 0;
break;
case FSIGN_POST:
*flags += FLAG_N_SIGNED;
*_2928 = SIGN_NEG_TRAIL;
break;
case FSIGN_PRE:
*flags += FLAG_N_SIGNED;
*_2928 = SIGN_NEG_LEAD;
break;
case FSIGN_POSTPLUS:
*flags += FLAG_N_SIGNED;
*_2928 = SIGN_ALL_TRAIL;
break;
case FSIGN_PREPLUS:
*flags += FLAG_N_SIGNED;
*_2928 = SIGN_ALL_LEAD;
break;
case FSIGN_FINANCIAL:
*flags += FLAG_N_SIGNED;
*_2928 = SIGN_FINANCIAL;
break;
}
switch (_2983 (_2901))
{
case FDECFMT_NONE:
*_2929 = 0;
break;
case FDECFMT_ALL:
*flags += FLAG_N_DECIMALS;
*_2929 = DECS_SHOW_ALL;
break;
case FDECFMT_DROP:
*flags += FLAG_N_DECIMALS;
*_2929 = DECS_DROP_ZEROS;
break;
}
switch (_2984 (_2901))
{
case FFILL_NONE:
*width = 0;
break;
case FFILL_SPACE:
*width = _2979 (_2901);
break;
case FFILL_ZERO:
*width = _2979 (_2901);
*flags += FLAG_N_ZERO_FILL;
break;
}
if (_2985 (_2901))
*flags += FLAG_N_ZERO_BLANK;
if (_2986 (_2901))
*flags += FLAG_N_THOUSANDS;
}
static void
_2912 (VDESCR *stream, byte *_2901, int _2942, int index)
{
char
*picture;
int
flags,
format;
long
_3077;
char
*value;
_3048
*_3070;
byte
attr;
_3077 = atol (_2925 (_2942, index));
picture = _2999 (_2901);
if (strused (picture))
value = conv_date_pict (_3077, picture);
else
{
if (_2992 (_2901) == FSHOW_YMD)
if (_2993 (_2901) == FFORMAT_COMPACT)
format = DATE_YMD_COMPACT;
else
if (_2993 (_2901) == FFORMAT_SLASH)
format = DATE_YMD_DELIM;
else
if (_2993 (_2901) == FFORMAT_SPACE)
format = DATE_YMD_SPACE;
else
if (_2993 (_2901) == FFORMAT_COMMA)
format = DATE_YMD_COMMA;
else
format = DATE_YMD_COMPACT;
else
if (_2992 (_2901) == FSHOW_YM)
if (_2993 (_2901) == FFORMAT_COMPACT)
format = DATE_YM_COMPACT;
else
if (_2993 (_2901) == FFORMAT_SLASH)
format = DATE_YM_DELIM;
else
if (_2993 (_2901) == FFORMAT_SPACE)
format = DATE_YM_SPACE;
else
format = DATE_YM_COMPACT;
else
if (_2992 (_2901) == FSHOW_MD)
if (_2993 (_2901) == FFORMAT_COMPACT)
format = DATE_MD_COMPACT;
else
if (_2993 (_2901) == FFORMAT_SLASH)
format = DATE_MD_DELIM;
else
if (_2993 (_2901) == FFORMAT_SPACE)
format = DATE_MD_SPACE;
else
format = DATE_MD_COMPACT;
else
format = DATE_YMD_COMPACT;
flags = 0;
if (_2994(_2901) == FYEAR_FULL)
flags += FLAG_D_CENTURY;
if (_2995 (_2901) == FMONTH_COUNTER)
flags += FLAG_D_MM_AS_M;
else
if (_2995 (_2901) == FMONTH_ALPHA)
flags += FLAG_D_MONTH_ABC;
else
if (_2995 (_2901) == FMONTH_UPPER)
flags += FLAG_D_UPPER;
if (_2996 (_2901) == FDAY_COUNTER)
flags += FLAG_D_DD_AS_D;
value = conv_date_str (_3077, flags, format,
_2892-> date_order,
_2892-> date_sep,
_2991 (_2901));
}
if (value == NULL)
value = conv_reason_text [conv_reason];
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> input && _2922 (_2942, index))
{
_2920 (_2901, _2942, index, attr);
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<INPUT TYPE=%s NAME=\"%s\" SIZE=%d MAXLENGTH=%d VALUE=\"%s\">\n",
_3070-> input,
_2926 (_2901, index),
_2991 (_2901),
_2991 (_2901),
attr == FATTR_SECURE? "": value);
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
if (!_3070-> _3047)
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
static void
_2913 (VDESCR *stream, byte *_2901, int _2942, int index)
{
_3048
*_3070;
char
*attrs,
*value;
byte
attr;
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
value = (attr == FATTR_SECURE? "": _2925 (_2942, index));
if (_3004 (_2901) & _3045)
strupc (value);
if (_3070-> _3047)
;
else
if (_3070-> input && _2922 (_2942, index))
{
_2920 (_2901, _2942, index, attr);
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<TEXTAREA NAME=\"%s\" ROWS=%d COLS=%d MAXLENGTH=%d WRAP=\"%s\">",
_2926 (_2901, index),
_3002 (_2901),
_3003 (_2901),
_3005 (_2901),
"VIRTUAL");
while (*value)
{
if (*value == '<')
_2905 (stream, "&lt;");
else
if (*value == '>')
_2905 (stream, "&gt;");
else
_2904 (stream, value, 1);
value++;
}
_2905 (stream, "</TEXTAREA>\n");
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
{
attrs = _3070-> output;
while (*attrs)
{
if (*attrs == '%')
{
attrs += 2;
break;
}
_2904 (stream, attrs, 1);
attrs++;
}
if (*value)
while (*value)
{
if (*value == '\n')
_2905 (stream, "<BR>");
else
_2904 (stream, value, 1);
value++;
}
else
_2905 (stream, "&nbsp;");
while (*attrs)
_2904 (stream, attrs++, 1);
}
}
static void
_2914 (VDESCR *stream, byte *_2901, int _2942, int index)
{
_3048
*_3070;
char
*value;
byte
attr;
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> _3047)
;
else
if (_3070-> input && _2922 (_2942, index))
{
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream,
"<INPUT TYPE=CHECKBOX %sNAME=\"%s\">\n",
_2925 (_2942, index) [0] == '1'? "CHECKED ": "",
_2926 (_2901, index));
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
{
value = _2925 (_2942, index) [0] == '1'?
_3012 (_2901): _3013 (_2901);
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
}
static void
_2915 (VDESCR *stream, byte *_2901, int _2942, int index)
{
_3048
*_3070;
int
_3078,
_3079,
_3080;
char
*value,
*_3081;
byte
attr;
_3080 = atoi (_2925 (_2942, index));
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> _3047)
;
else
if (_3070-> input && _2922 (_2942, index))
{
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream, "<SELECT NAME=\"%s\" SIZE=%d>\n",
_2926 (_2901, index),
_3016 (_2901));
if (_3017 (_2901) == 0)
{
_3079 = fxlist_size (_2942, index);
for (_3078 = 1; _3078 <= _3079; _3078++)
_2906 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _3078,
_3078 == _3080? " SELECTED": "",
_2938 (_2942, index, _3078, 'v'));
}
else
{
_2906 (stream, "<OPTION VALUE=\"0\"%s>%s\n",
_3080 == 0? " SELECTED": "",
_3020 (_2901));
_3081 = _3021 (_2901);
for (_3078 = 1; _3078 <= _3017 (_2901); _3078++)
{
_2906 (stream, "<OPTION VALUE=\"%d\"%s>%s\n", _3078,
_3078 == _3080? " SELECTED": "",
_3081);
_3081 += strlen (_3081) + 1;
}
}
_2905 (stream, "</SELECT>\n");
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (_3080 == 0)
_2906 (stream, _3070-> output, _3020 (_2901));
else
{
if (_3017 (_2901) == 0)
value = _2938 (_2942, index, _3080, 'v');
else
{
_3081 = _3020 (_2901);
for (_3078 = 0; _3078 < _3080; _3078++)
_3081 += strlen (_3081) + 1;
value = _3081;
}
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
_2906 (stream, _3070-> output, *value? value: "&nbsp;");
}
}
static void
_2916 (VDESCR *stream, byte *_2901, int _2942, int index)
{
_3048
*_3070;
int
_3082;
byte
*_3083;
char
*value;
byte
attr;
_3082 = atoi (_2925 (_2942, index));
_3083 = _2892-> defn-> blocks + _3029 (_2901);
attr = *_2924 (_2942, index);
_3070 = &_3049 [attr];
if (_3070-> _3047)
;
else
if (_3070-> input && _2922 (_2942, index))
{
if (_3030 (_2901) > 1 && _3025 (_3083))
_2905 (stream, "<BR>");
if (_3070-> _3046)
_2905 (stream, _2897);
_2906 (stream, "<INPUT TYPE=RADIO VALUE=\"%d\" NAME=\"%s\"%s>%s\n",
_3030 (_2901),
_2926 (_3083, index),
_3030 (_2901) == _3082? " CHECKED": "",
_3031 (_2901));
if (_3070-> _3046)
_2905 (stream, _2898);
}
else
if (_3024 (_3083))
{
if (_3030 (_2901) > 1 && _3025 (_3083))
_2905 (stream, "<BR>");
value = xstrcpy (NULL,
_3030 (_2901) == _3082?
" (*) ": " (&nbsp;) ",
_3031 (_2901),
NULL);
if (attr == FATTR_OPTION)
_2919 (stream, value, _2942, index);
else
_2906 (stream, _3070-> output, value);
mem_free (value);
}
else
if (_3082 == 0 && _3030 (_2901) == 1)
{
if (attr == FATTR_OPTION)
_2919 (stream, _3028 (_3083), _2942, index);
else
_2906 (stream, _3070-> output, _3028 (_3083));
}
else
if (_3030 (_2901) == _3082)
{
if (attr == FATTR_OPTION)
_2919 (stream, _3031 (_2901), _2942, index);
else
_2906 (stream, _3070-> output, _3031 (_2901));
}
}
static void
_2917 (VDESCR *stream, byte *_2901, int index)
{
if (*_3044 (_2901) == FACTION_ENABLED)
{
if (_3032 (_2901) == FTYPE_BUTTON)
_2906 (stream, "<INPUT TYPE=SUBMIT VALUE=\"%s\" NAME=\"%s\">\n",
_3039 (_2901), _3038 (_2901));
else
if (_3032 (_2901) == FTYPE_PLAIN)
{
if (_2892-> JavaScript)
_2906 (stream,
"<A HREF=\"javascript:submit('~A%d.%d')\">%s</A>\n",
_3033 (_2901), index,
_3039 (_2901));
else
_2906 (stream, "<A HREF=\"#(uri)&~A%d.%d=1\">%s</A>\n",
_3033 (_2901), index,
_3039 (_2901));
}
else
if (_3032 (_2901) == FTYPE_IMAGE)
{
if (_2892-> JavaScript)
{
_2906   (stream, "<A HREF=\"javascript:submit('~A%d.%d')\">",
_3033 (_2901), index);
_2918 (stream, _2901);
_2906   (stream, "</A>");
}
else
{
_2906 (stream,
"<INPUT TYPE=IMAGE BORDER=0 SRC=\"%s\" NAME=\"%s\"",
_3039 (_2901), _3038 (_2901));
if (_3036 (_2901))
_2906 (stream, " HEIGHT=%d WIDTH=%d",
_3036 (_2901),
_3037 (_2901));
}
}
}
else
if (*_3044 (_2901) == FACTION_DISABLED)
{
if (_3032 (_2901) == FTYPE_BUTTON)
_2906 (stream, "&nbsp;[ %s ]&nbsp;\n", _3039 (_2901));
else
if (_3032 (_2901) == FTYPE_PLAIN)
_2906 (stream, "%s\n", _3039 (_2901));
else
if (_3032 (_2901) == FTYPE_IMAGE)
_2918 (stream, _2901);
}
}
static void
_2918 (VDESCR *stream, byte *_2901)
{
char
*_3084;
_3084 = mem_strdup (_3038 (_2901));
_3084 [0] = toupper (_3084 [0]);
_2906 (stream, "<IMG BORDER=0 SRC=\"%s\" ALT=\"%s\"",
_3039 (_2901), _3084);
if (_3036 (_2901))
_2906 (stream, " HEIGHT=%d WIDTH=%d",
_3036 (_2901), _3037 (_2901));
_2906 (stream, ">");
mem_free (_3084);
}
int
form_get (
FORM_ITEM *form,
const char *query)
{
SYMTAB
*symtab;
int
_3085 = 0;
ASSERT (form);
ASSERT (query);
if ((symtab = http_query2symb (query)) == NULL)
return 0;
form-> status = FSTATUS_OK;
form-> image_x = 0;
form-> image_y = 0;
form-> click_field = 0;
form-> click_index = 0;
strclr (form-> livelink);
form-> event = form-> click_event;
mem_check (form-> data);
form_use (form);
if (*query == '&' || *query == '~')
sym_exec_all (symtab, _2947);
else
{
form_exec (form, _2944, symtab, &_3085);
_2948 (symtab);
}
sym_delete_table (symtab);
return (form-> status == FSTATUS_OK? _3085: -1);
}
static Bool
_2944 (
FORM_ITEM *form,
byte *_2901,
int _2942,
va_list _2943)
{
static int
_3086,
_3087 = 0;
SYMTAB
*symtab;
SYMBOL
*symbol;
byte
_3056;
int
_3088,
*_3089,
_3090,
index;
symtab = va_arg (_2943, SYMTAB *);
_3089 = va_arg (_2943, int *);
if (_2942 == -1)
_3086 = 0;
mem_check (form-> data);
_3056 = _2950 (_2901);
if (_3040 (_3056))
{
_3090 = _3086? _3087: 1;
for (index = 0; index < _3090; index++)
{
if (_3056 == BLOCK_BOOLEAN)
strcpy (_2925 (_2942, index), "0");
_2931 (_2942, index);
symbol = sym_lookup_symbol (symtab, _2926 (_2901, index));
if (symbol)
{
_3088 = _2930 (_2901, _2942, index,
symbol-> value);
if (_3088 == -1)
form-> status = FSTATUS_FIELD;
else
*_3089 += _3088;
}
}
}
else
if (_3056 == BLOCK_ACTION)
_2936 (symtab, _2901);
else
if (_3056 == BLOCK_REPEAT)
{
_3086 = _2962 (_2901) + 1;
_3087 = atoi (_2925 (_2961 (_2901), 0));
}
if (_3086)
_3086--;
return (TRUE);
}
static int
_2930 (byte *_2901, int _2942, int index, char *value)
{
switch (_2950 (_2901))
{
case BLOCK_TEXTUAL:
return (_2932 (_2901, _2942, index, value));
case BLOCK_TEXTBOX:
return (_2933 (_2901, _2942, index, value));
case BLOCK_SELECT:
case BLOCK_RADIO:
case BLOCK_FILE:
return (fxputn_text (_2942, index, value));
case BLOCK_NUMERIC:
return (_2934 (_2901, _2942, index, value));
case BLOCK_DATE:
return (_2935 (_2901, _2942, index, value));
case BLOCK_BOOLEAN:
return (fxputn_text (_2942, index, "1"));
}
return (0);
}
static int
_2932 (byte *_2901, int _2942, int index, char *value)
{
if (_2966 (_2901) & _3045)
strupc (value);
return (fxputn_text (_2942, index, value));
}
static int
_2933 (byte *_2901, int _2942, int index, char *value)
{
if (_3004 (_2901) & _3045)
strupc (value);
return (fxputn_text (_2942, index, value));
}
static int
_2934 (byte *_2901, int _2942, int index, char *value)
{
static char
_3091 [LINE_MAX];
int
_3074,
sign_format,
_3075,
_3092;
char
*_3093;
byte
*attr;
_2927 (
_2901,
&_3074,
&sign_format,
&_3075,
&_3092);
_3092 = _2979 (_2901);
_3093 = conv_str_number
(
value,
_3074,
_2892-> dec_point,
_2981 (_2901),
_3075,
_3092
);
if (_3093 == NULL)
{
xstrcpy (_3091, "Invalid number (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _3091;
attr = _2924 (_2942, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_text (_2942, index, _3093));
}
static int
_2935 (byte *_2901, int _2942, int index, char *value)
{
static char
_3094 [LINE_MAX];
int
format;
long
_3077 = -1;
byte
*attr;
if (_2992 (_2901) == FSHOW_YMD)
format = DATE_YMD_DELIM;
else
if (_2992 (_2901) == FSHOW_YM)
format = DATE_YM_DELIM;
else
format = DATE_MD_DELIM;
_3077 = conv_str_date (value, 0, format, _2892-> date_order);
if (_3077 == -1)
{
xstrcpy (_3094, "Invalid date (", value, "): ",
conv_reason_text [conv_reason], NULL);
form_strerror = _3094;
attr = _2924 (_2942, index);
if (*attr == FATTR_INPUT)
*attr = FATTR_ERROR;
return (-1);
}
else
return (fxputn_date (_2942, index, _3077));
}
static void
_2931 (int _2942, int index)
{
byte
*attr;
attr = _2924 (_2942, index);
if (*attr == FATTR_ERROR)
*attr = FATTR_INPUT;
}
static void
_2936 (SYMTAB *symtab, byte *_2901)
{
SYMBOL
*symbol;
char
*_3095;
if (_3032 (_2901) == FTYPE_IMAGE)
{
_3095 = xstrcpy (NULL, _3038 (_2901), ".x", NULL);
symbol = sym_lookup_symbol (symtab, _3095);
if (symbol)
{
_2892-> event = _3033 (_2901);
_2892-> image_x = atoi (symbol-> value);
strlast (_3095) = 'y';
symbol = sym_lookup_symbol (symtab, _3095);
if (symbol)
_2892-> image_y = atoi (symbol-> value);
}
mem_free (_3095);
}
else
{
symbol = sym_lookup_symbol (symtab, _3038 (_2901));
if (symbol)
_2892-> event = _3033 (_2901);
}
}
static Bool
_2947 (SYMBOL *symbol, ...)
{
char
*_3096;
if (symbol-> name [0] == '~')
{
_3096 = strchr (symbol-> name + 2, '.');
if (_3096)
_2892-> click_index = atoi (_3096 + 1);
if (symbol-> name [1] == 'C')
{
_2892-> click_field = atoi (symbol-> name + 2);
_2892-> event = _2892-> click_event;
return (FALSE);
}
else
if (symbol-> name [1] == 'A')
{
_2892-> event = atoi (symbol-> name + 2);
return (FALSE);
}
else
if (symbol-> name [1] == 'L')
{
strncpy (_2892-> livelink, symbol-> name + 2,
FORMIO_LIVELINK_MAX);
_2892-> livelink [FORMIO_LIVELINK_MAX] = '\0';
_2892-> event = _2892-> click_event;
return (FALSE);
}
}
return (TRUE);
}
static void
_2948 (SYMTAB *symtab)
{
SYMBOL
*symbol;
char
*_3096;
symbol = sym_lookup_symbol (symtab, "jsaction");
if (symbol && symbol-> value [0] == '~')
{
_3096 = strchr (symbol-> value + 2, '.');
if (_3096)
_2892-> click_index = atoi (_3096 + 1);
if (symbol-> value [1] == 'C')
{
_2892-> click_field = atoi (symbol-> value + 2);
_2892-> event = _2892-> click_event;
}
else
if (symbol-> value [1] == 'A')
_2892-> event = atoi (symbol-> value + 2);
else
if (symbol-> value [1] == 'L')
{
strncpy (_2892-> livelink, symbol-> value + 2,
FORMIO_LIVELINK_MAX);
_2892-> livelink [FORMIO_LIVELINK_MAX] = '\0';
_2892-> event = _2892-> click_event;
}
}
}
int
fxputn_text (int field, int index, const char *new_value)
{
char
*value;
ASSERT (new_value);
ASSERT (index < _2952 (_3042 (field)));
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
value = _2925 (field, index);
if (streq (value, new_value))
return (0);
else
{
strncpy (value, new_value, _3043 (field));
value [_3043 (field)] = '\0';
strcrop (value);
return (1);
}
}
int
fxputn_date (int field, int index, long new_value)
{
ASSERT (index < _2952 (_3042 (field)));
return (fxputn_long (field, index, new_value));
}
int
fxputn_int (int field, int index, int new_value)
{
ASSERT (index < _2952 (_3042 (field)));
return (fxputn_long (field, index, (long) new_value));
}
int
fxputn_long (int field, int index, long new_value)
{
static char
_3073 [20];
ASSERT (index < _2952 (_3042 (field)));
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
sprintf (_3073, "%ld", new_value);
return (fxputn_text (field, index, _3073));
}
int
fxputn_double (int field, int index, double new_value)
{
static char
_3073 [40],
format [10];
ASSERT (index < _2952 (_3042 (field)));
sprintf (format, "%%.%df", _2981 (_3042 (field)));
sprintf (_3073, format, new_value);
return (fxputn_text (field, index, _3073));
}
int
fxputn_bool (int field, int index, Bool new_value)
{
ASSERT (index < _2952 (_3042 (field)));
return (fxputn_text (field, index, new_value? "1": "0"));
}
char *
fxgetn_text (int field, int index)
{
if (field < 0 || field >= _2892-> defn-> field_count)
return (NULL);
ASSERT (index < _2952 (_3042 (field)));
return (_2925 (field, index));
}
long
fxgetn_date (int field, int index)
{
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
ASSERT (index < _2952 (_3042 (field)));
ASSERT (_2950 (_3042 (field)) == BLOCK_DATE);
return (atol (_2925 (field, index)));
}
int
fxgetn_int (int field, int index)
{
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
ASSERT (index < _2952 (_3042 (field)));
return (atoi (_2925 (field, index)));
}
long
fxgetn_long (int field, int index)
{
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
ASSERT (index < _2952 (_3042 (field)));
return (atol (_2925 (field, index)));
}
double
fxgetn_double (int field, int index)
{
if (field < 0 || field >= _2892-> defn-> field_count)
return (0);
ASSERT (index < _2952 (_3042 (field)));
return (atof (_2925 (field, index)));
}
Bool
fxgetn_bool (int field, int index)
{
ASSERT (index < _2952 (_3042 (field)));
return (fxgetn_long (field, index)? TRUE: FALSE);
}
byte
fxattr_get (
int _2942,
int index)
{
FORM_DEFN
*defn;
defn = _2892-> defn;
ASSERT (_2942 >= 0 && _2942 < defn-> field_count);
return (*_2924 (_2942, index));
}
void
fxattr_put (
int _2942,
int index,
byte attr)
{
FORM_DEFN
*defn;
defn = _2892-> defn;
ASSERT (_2942 >= 0 && _2942 < defn-> field_count);
*_2924 (_2942, index) = attr;
}
size_t
fxlist_size (int field, int index)
{
return (atoi (_2938 (field, index, 0, 'h')));
}
static char *
_2940 (int field, int index, int item, char _2939)
{
static char
key [11];
sprintf (key, "%02x.%02x.%02x.%c",
(byte) field, (byte) index, (byte) item, _2939);
return (key);
}
static char *
_2938 (int field, int index, int item, char _2939)
{
SYMBOL
*symbol;
if (_2892-> list_values)
{
symbol = sym_lookup_symbol (_2892-> list_values,
_2940 (field, index, item, _2939));
if (symbol)
return (symbol-> value);
}
return ("");
}
void
fxlist_reset (int field, int index)
{
SYMBOL
*symbol;
int
item;
if (_2892-> list_values == NULL)
_2892-> list_values = sym_create_table ();
item = fxlist_size (field, index);
while (item > 0)
{
symbol = sym_lookup_symbol (_2892-> list_values,
_2940 (field, index, item, 'k'));
if (symbol)
sym_delete_symbol (_2892-> list_values, symbol);
symbol = sym_lookup_symbol (_2892-> list_values,
_2940 (field, index, item, 'v'));
if (symbol)
sym_delete_symbol (_2892-> list_values, symbol);
item--;
}
sym_create_symbol (_2892-> list_values,
_2940 (field, index, 0, 'h'), "000");
}
int
fxlist_append (int field, int index, char *key, char *value)
{
SYMBOL
*symbol;
int
_3097;
ASSERT (_2892-> list_values);
symbol = sym_lookup_symbol (_2892-> list_values,
_2940 (field, index, 0, 'h'));
if (symbol == NULL)
return (0);
_3097 = fxlist_size (field, index);
if (_3097 == 999)
return (_3097);
_3097++;
sym_assume_symbol (_2892-> list_values,
_2940 (field, index, _3097, 'k'), key);
sym_assume_symbol (_2892-> list_values,
_2940 (field, index, _3097, 'v'), value);
sprintf (symbol-> value, "%d", _3097);
return (_3097);
}
char *
fxlist_key (int field, int index)
{
return (_2938 (field, index, fxgetn_int (field, index), 'k'));
}
char *
fxlist_value (int field, int index)
{
return (_2938 (field, index, fxgetn_int (field, index), 'v'));
}
void
fxlist_set (int field, int index, char *key)
{
int
item;
ASSERT (_2892-> list_values);
item = fxlist_size (field, index);
while (item > 0)
{
if (streq (_2938 (field, index, item, 'k'), key))
break;
item--;
}
fxputn_int (field, index, item);
}
int
form_exec (
FORM_ITEM *form,
blockfunc _3098,
...)
{
va_list
_2943;
byte
*_2901;
word
block_size;
int
_2942,
_3058,
count = 0;
ASSERT (form);
va_start (_2943, _3098);
_2942 = -1;
_2901 = form-> defn-> blocks;
for (_3058 = 0; _3058 < form-> defn-> block_count; _3058++)
{
block_size = _2949 (_2901);
ASSERT (block_size > 0);
if (_3040 (_2950 (_2901)))
_2942++;
if ((*_3098) (form, _2901, _2942, _2943))
count++;
else
break;
_2901 += block_size + 2;
}
va_end (_2943);
return (count);
}
void
action_enable (FORM_ITEM *form, int event)
{
form_exec (form, _2946, event, FACTION_ENABLED);
}
static Bool
_2946 (
FORM_ITEM *form,
byte *_2901,
int _2942,
va_list _2943)
{
int
event,
attr;
event = va_arg (_2943, int);
attr = va_arg (_2943, int);
_2892 = form;
if (_2950 (_2901) == BLOCK_ACTION)
{
if (event == -1
|| event == _3033 (_2901))
*_3044 (_2901) = attr;
}
return (TRUE);
}
void
action_disable (FORM_ITEM *form, int event)
{
form_exec (form, _2946, event, FACTION_DISABLED);
}
void
action_hide (FORM_ITEM *form, int event)
{
form_exec (form, _2946, event, FACTION_HIDDEN);
}
int
form_save (
const char *filename,
FORM_ITEM *form)
{
FILE
*stream;
stream = fopen (filename, FOPEN_WRITE_BINARY);
if (stream)
{
fwrite (form, sizeof (FORM_ITEM), 1, stream);
fwrite (form-> data, form-> data_size, 1, stream);
fclose (stream);
return (0);
}
else
return (-1);
}
FORM_ITEM *
form_load (
const char *filename,
FORM_DEFN *defn)
{
FILE
*stream;
FORM_ITEM
*form;
byte
*data;
stream = fopen (filename, FOPEN_READ_BINARY);
if (!stream)
return (NULL);
if ((form = _2899 (defn)) == NULL)
return (NULL);
data = form-> data;
fread (form, sizeof (FORM_ITEM), 1, stream);
form-> data = data;
form-> defn = defn;
fread (form-> data, form-> data_size, 1, stream);
mem_check (form-> data);
fclose (stream);
return (form);
}
void
form_dump (FORM_ITEM *form)
{
int
_3058 = 0;
ASSERT (form);
printf ("Dumping contents of form %s\n", form-> defn-> form_name);
printf ("Block: Size:  Type:      Details:\n");
form_exec (form, _2945, &_3058);
}
static Bool
_2945 (
FORM_ITEM *form,
byte *_2901,
int _2942,
va_list _2943)
{
byte
*_3069;
word
block_size;
int
*_3058;
_3058 = va_arg (_2943, int *);
block_size = _2949 (_2901);
printf ("%p %-6d %-6d ", _2901, *_3058, block_size);
(*_3058)++;
switch (_2950 (_2901))
{
case BLOCK_PLAIN:
printf ("plain      ");
_2901 += 2;
block_size--;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_2901);
printf ("\n");
break;
case BLOCK_COMPRESSED:
printf ("compressed ");
_3069 = _2955 (_2901) + form-> defn-> blocks;
if (_2954 (_2901) == COMPR_WHOLEDICT)
block_size = _2949 (_3069) - 1;
else
if (_2954 (_2901) == COMPR_PARTDICT)
block_size = _2956 (_2901);
else
abort ();
_3069 += 2;
if (block_size > 50)
block_size = 50;
while (block_size-- > 0)
printf ("%c", *++_3069);
printf ("\n");
break;
case BLOCK_IF:
printf ("if         ");
printf ("field=%d scope=%d\n",
_2957 (_2901),
_2958 (_2901));
break;
case BLOCK_UNLESS:
printf ("unless     ");
printf ("field=%d scope=%d\n",
_2959 (_2901),
_2960 (_2901));
break;
case BLOCK_REPEAT:
printf ("repeat     ");
printf ("field=%d scope=%d occurs=%d\n",
_2961 (_2901),
_2962 (_2901),
_2963 (_2901));
break;
case BLOCK_TEXTUAL:
printf ("textual    ");
printf ("x%d attr=%d size=%d max=%d name=%s value=%s\n",
_2965 (_2901),
_2964 (_2901),
_2967 (_2901),
_2968 (_2901),
_2969 (_2901),
_2970 (_2901));
break;
case BLOCK_FILE:
printf ("file       ");
printf ("x%d attr=%d size=%d max=%d name=%s value=%s\n",
_2972 (_2901),
_2971 (_2901),
_2973 (_2901),
_2974 (_2901),
_2975 (_2901),
_2976 (_2901));
break;
case BLOCK_NUMERIC:
printf ("numeric    ");
printf ("x%d attr=%d size=%d max=%d sign=%d decs=%d ",
_2978 (_2901),
_2977 (_2901),
_2979 (_2901),
_2980 (_2901),
_2982 (_2901),
_2981 (_2901));
printf ("fill=%d blank=%d comma=%d name=%s value=%s\n",
_2984 (_2901),
_2985 (_2901),
_2986 (_2901),
_2987 (_2901),
_2988 (_2901));
break;
case BLOCK_DATE:
printf ("date       ");
printf ("x%d attr=%d size=%d show=%d format=%d year=%d ",
_2990 (_2901),
_2989 (_2901),
_2991 (_2901),
_2992 (_2901),
_2993 (_2901),
_2994 (_2901));
printf ("month=%d day=%d name=%s value=%s picture=%s\n",
_2995 (_2901),
_2996 (_2901),
_2997 (_2901),
_2998 (_2901),
_2999 (_2901));
break;
case BLOCK_TEXTBOX:
printf ("textbox    ");
printf ("x%d attr=%d rows=%d cols=%d max=%d name=%s value=%s\n",
_3001 (_2901),
_3000 (_2901),
_3002 (_2901),
_3003 (_2901),
_3005 (_2901),
_3006 (_2901),
_3007 (_2901));
break;
case BLOCK_BOOLEAN:
printf ("boolean    ");
printf ("x%d attr=%d name=%s value=%s\n",
_3009 (_2901),
_3008 (_2901),
_3010 (_2901),
_3011 (_2901));
break;
case BLOCK_SELECT:
printf ("select     ");
printf ("x%d attr=%d size=%d opts=%d name=%s value=%s first=%s\n",
_3015 (_2901),
_3014 (_2901),
_3016 (_2901),
_3017 (_2901),
_3018 (_2901),
_3019 (_2901),
_3021 (_2901));
break;
case BLOCK_RADIO:
printf ("radio      ");
printf ("x%d attr=%d detail=%d column=%d name=%s value=%s\n",
_3023 (_2901),
_3022 (_2901),
_3024 (_2901),
_3025 (_2901),
_3026 (_2901),
_3027 (_2901));
break;
case BLOCK_RLABEL:
printf ("rlabel     ");
printf ("data=%d index=%d value=%s\n",
_3029 (_2901),
_3030 (_2901),
_3031 (_2901));
break;
case BLOCK_ACTION:
printf ("action     ");
printf ("type=%d event=%d show=%d height=%d width=%d label=%s\n",
_3032 (_2901),
_3033 (_2901),
_3035 (_2901),
_3036 (_2901),
_3037 (_2901),
_3039 (_2901));
break;
default:
printf ("ERROR!\n");
abort ();
}
return (TRUE);
}
int
form_ftype (
FORM_ITEM *form,
int _2942)
{
FORM_DEFN
*defn;
ASSERT (form);
defn = form-> defn;
if (_2942 < 0 || _2942 >= defn-> field_count)
return (0);
else
return (_2950 (defn-> blocks + defn-> fields [_2942].block));
}
