/*---------------------------------------------------------------------------
 *  xiadm02.h - HTML form definition
 *
 *  Generated 1998/04/25,  9:11:48 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM02__
#define __FORM_XIADM02__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define CONFIG_LIST_MAX                     10
#define XIADM02_MESSAGE_TO_USER             0
#define XIADM02_L_FILENAME                  1
#define XIADM02_L_FILEDATE                  2
#define XIADM02_L_FILESIZE                  3
#define XIADM02_FILENAME                    4
#define XIADM02_FILEDATE                    5
#define XIADM02_FILETIME                    6
#define XIADM02_FILESIZE                    7
#define XIADM02_L_NEWFILE                   8
#define XIADM02_NEWFILE                     9
#define XIADM02_CONFIG_LIST                 10

/*  This table contains each block in the form                               */

static byte xiadm02_blocks [] = {
    /*  <HTML><HEAD><TITLE>Virtual Hosts Configuration</TITLE>               */
    0, 56, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'V', 'i', 'r', 't', 'u',
    'a', 'l', 32, 'H', 'o', 's', 't', 's', 32, 'C', 'o', 'n', 'f', 'i',
    'g', 'u', 'r', 'a', 't', 'i', 'o', 'n', '<', '/', 'T', 'I', 'T',
    'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 158, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'A',
    32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u', 'r', 'i', ')', '&',
    '~', 'L', 'c', 'o', 'n', 's', 'o', 'l', 'e', '=', '1', '"', '>',
    'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'A', '>', 32, '|', 32,
    '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=', '"', 'H', 'e', 'l',
    'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x', 'i', 't', 'a', 'm',
    'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.', 'h', 't', 'm', '"',
    '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>', '<', 'F', 'O', 'N',
    'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  Virtual Hosts Configuration                                          */
    0, 29, 0, 'V', 'i', 'r', 't', 'u', 'a', 'l', 32, 'H', 'o', 's', 't',
    's', 32, 'C', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't', 'i', 'o',
    'n', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 163,
    /*  <P>Select a configuration:<BR>                                       */
    0, 32, 0, '<', 'P', '>', 'S', 'e', 'l', 'e', 'c', 't', 32, 'a', 32,
    'c', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't', 'i', 'o', 'n',
    ':', '<', 'B', 'R', '>', 10,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE NOWRAP WIDTH=75%  BORDER=1>                                   */
    0, 36, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'N', 'O', 'W', 'R', 'A',
    'P', 32, 'W', 'I', 'D', 'T', 'H', '=', '7', '5', '%', 32, 32, 'B',
    'O', 'R', 'D', 'E', 'R', '=', '1', '>', 10,
    /*  <TR>                                                                 */
    0, 6, 0, '<', 'T', 'R', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f1 NAME=L_filename VALUE="Name:"                    */
    0, 17, 10, 6, 1, 0, 0, 5, 0, 5, 'f', '1', 0, 'N', 'a', 'm', 'e',
    ':', 0,
    /*  </TH>                                                                */
    0, 7, 0, '<', '/', 'T', 'H', '>', 10,
    /*  <TH ALIGN=CENTER VALIGN=TOP COLSPAN=2>                               */
    0, 40, 0, '<', 'T', 'H', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', 32, 'C', 'O', 'L', 'S', 'P', 'A', 'N', '=', '2', '>', 10,
    /*  !--FIELD TEXTUAL f2 NAME=L_filedate VALUE="Last modified:"           */
    0, 26, 10, 6, 1, 0, 0, 14, 0, 14, 'f', '2', 0, 'L', 'a', 's', 't',
    32, 'm', 'o', 'd', 'i', 'f', 'i', 'e', 'd', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 133,
    /*  <TH ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 2, 'R',
    /*  !--FIELD TEXTUAL f3 NAME=L_filesize VALUE="Size, lines:"             */
    0, 24, 10, 6, 1, 0, 0, 12, 0, 12, 'f', '3', 0, 'S', 'i', 'z', 'e',
    ',', 32, 'l', 'i', 'n', 'e', 's', ':', 0,
    /*  </TH>                                                                */
    0, 4, 1, 0, 2, 133,
    /*  !--REPEAT config_list  ROWS=10                                       */
    0, 7, 4, 0, 10, 0, 15, 0, 10,
    /*  </TR>                                                                */
    0, 7, 0, '<', '/', 'T', 'R', '>', 10,
    /*  <TR>                                                                 */
    0, 4, 1, 0, 2, 'J',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 30, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'C', 'E',
    'N', 'T', 'E', 'R', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=', 'T', 'O',
    'P', '>', 10,
    /*  !--FIELD TEXTUAL f4 NAME=fil ... E=40 MAX=? UPPER=0 VALUE=""         */
    0, 12, 10, 10, 10, 0, 0, '(', 0, '(', 'f', '4', 0, 0,
    /*  </TD>                                                                */
    0, 7, 0, '<', '/', 'T', 'D', '>', 10,
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 24,
    /*  !--FIELD DATE f5 NAME=fileda ... AR=? MONTH=? DAY=? VALUE=""         */
    0, 15, 12, 6, 10, 0, 15, 0, 1, 0, 0, 0, 'f', '5', 0, 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'F',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 24,
    /*  !--FIELD TEXTUAL f6 NAME=fil ... ZE=5 MAX=? UPPER=0 VALUE=""         */
    0, 12, 10, 6, 10, 0, 0, 5, 0, 5, 'f', '6', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'F',
    /*  <TD ALIGN=CENTER VALIGN=TOP>                                         */
    0, 4, 1, 0, 3, 24,
    /*  !--FIELD NUMERIC f7 NAME=fil ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 17, 11, 6, 10, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, 'f', '7', 0, 0,
    /*  </TD>                                                                */
    0, 4, 1, 0, 3, 'F',
    /*  </TR>                                                                */
    0, 4, 1, 0, 3, 9,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 156,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f8 NAME=L_n ... UE="Add new configuration:"         */
    0, 34, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '8', 0, 'A', 'd', 'd', 32,
    'n', 'e', 'w', 32, 'c', 'o', 'n', 'f', 'i', 'g', 'u', 'r', 'a', 't',
    'i', 'o', 'n', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD TEXTUAL f9 NAME=new ... E=40 MAX=? UPPER=0 VALUE=""         */
    0, 12, 10, 0, 1, 0, 0, '(', 0, '(', 'f', '9', 0, 0,
    /*  !--ACTION define  LABEL="Def ... NT=define_event TYPE=BUTTON         */
    0, 28, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 0, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'i', 'n',
    'e', 0, 'D', 'e', 'f', 'i', 'n', 'e', '.', '.', '.', 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 156,
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  !--ACTION more  LABEL="More..." EVENT=more_event TYPE=BUTTON         */
    0, 24, 20, 0, (byte) ((word) more_event / 256), (byte) ((word)
    more_event & 255), 0, 1, 0, 0, 0, 0, 0, 'm', 'o', 'r', 'e', 0, 'M',
    'o', 'r', 'e', '.', '.', '.', 0,
    /*  !--ACTION first  LABEL="First" EVENT=first_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) first_event / 256), (byte) ((word)
    first_event & 255), 0, 2, 0, 0, 0, 0, 0, 'f', 'i', 'r', 's', 't', 0,
    'F', 'i', 'r', 's', 't', 0,
    /*  <BR>                                                                 */
    0, 6, 0, '<', 'B', 'R', '>', 10,
    /*  !--ACTION defaults  LABEL="D ... =defaults_event TYPE=BUTTON         */
    0, 32, 20, 0, (byte) ((word) defaults_event / 256), (byte) ((word)
    defaults_event & 255), 0, 3, 0, 0, 0, 0, 0, 'd', 'e', 'f', 'a', 'u',
    'l', 't', 's', 0, 'D', 'e', 'f', 'a', 'u', 'l', 't', 's', '.', '.',
    '.', 0,
    /*   for all virtual hosts; choose this if you're uncertain<BR>          */
    0, 61, 0, 32, 'f', 'o', 'r', 32, 'a', 'l', 'l', 32, 'v', 'i', 'r',
    't', 'u', 'a', 'l', 32, 'h', 'o', 's', 't', 's', ';', 32, 'c', 'h',
    'o', 'o', 's', 'e', 32, 't', 'h', 'i', 's', 32, 'i', 'f', 32, 'y',
    'o', 'u', 39, 'r', 'e', 32, 'u', 'n', 'c', 'e', 'r', 't', 'a', 'i',
    'n', '<', 'B', 'R', '>', 10,
    /*  !--ACTION basehost  LABEL="B ... =basehost_event TYPE=BUTTON         */
    0, 33, 20, 0, (byte) ((word) basehost_event / 256), (byte) ((word)
    basehost_event & 255), 0, 4, 0, 0, 0, 0, 0, 'b', 'a', 's', 'e', 'h',
    'o', 's', 't', 0, 'B', 'a', 's', 'e', 32, 'h', 'o', 's', 't', '.',
    '.', '.', 0,
    /*   for unresolved virtual hosts<BR>                                    */
    0, 35, 0, 32, 'f', 'o', 'r', 32, 'u', 'n', 'r', 'e', 's', 'o', 'l',
    'v', 'e', 'd', 32, 'v', 'i', 'r', 't', 'u', 'a', 'l', 32, 'h', 'o',
    's', 't', 's', '<', 'B', 'R', '>', 10,
    /*  !--ACTION apply  LABEL="Appl ... T=restart_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) restart_event / 256), (byte) ((word)
    restart_event & 255), 0, 5, 0, 0, 0, 0, 0, 'a', 'p', 'p', 'l', 'y',
    0, 'A', 'p', 'p', 'l', 'y', 0,
    /*   restarts the server and reloads all configurations                  */
    0, 53, 0, 32, 'r', 'e', 's', 't', 'a', 'r', 't', 's', 32, 't', 'h',
    'e', 32, 's', 'e', 'r', 'v', 'e', 'r', 32, 'a', 'n', 'd', 32, 'r',
    'e', 'l', 'o', 'a', 'd', 's', 32, 'a', 'l', 'l', 32, 'c', 'o', 'n',
    'f', 'i', 'g', 'u', 'r', 'a', 't', 'i', 'o', 'n', 's', 10,
    /*  !--FIELD NUMERIC config_list SIZE=4 VALUE=10                         */
    0, 28, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'c', 'o', 'n', 'f',
    'i', 'g', '_', 'l', 'i', 's', 't', 0, '1', '0', 0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 156,
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm02_fields [] = {
    { 0, 119, 80 },                     /*  message_to_user                 */
    { 82, 626, 5 },                     /*  l_filename                      */
    { 89, 696, 14 },                    /*  l_filedate                      */
    { 105, 736, 12 },                   /*  l_filesize                      */
    { 119, 824, 40 },                   /*  filename                        */
    { 539, 853, 8 },                    /*  filedate                        */
    { 639, 882, 5 },                    /*  filetime                        */
    { 709, 908, 5 },                    /*  filesize                        */
    { 779, 1008, 22 },                  /*  l_newfile                       */
    { 803, 1087, 40 },                  /*  newfile                         */
    { 845, 1466, 4 },                   /*  config_list                     */
    { 851, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   l_filename_a         ;
    char   l_filename           [5 + 1];
    byte   l_filedate_a         ;
    char   l_filedate           [14 + 1];
    byte   l_filesize_a         ;
    char   l_filesize           [12 + 1];
    byte   filename_a           [10] ;
    char   filename             [10] [40 + 1];
    byte   filedate_a           [10] ;
    char   filedate             [10] [8 + 1];
    byte   filetime_a           [10] ;
    char   filetime             [10] [5 + 1];
    byte   filesize_a           [10] ;
    char   filesize             [10] [5 + 1];
    byte   l_newfile_a          ;
    char   l_newfile            [22 + 1];
    byte   newfile_a            ;
    char   newfile              [40 + 1];
    byte   config_list_a        ;
    char   config_list          [4 + 1];
    byte   define_a;
    byte   more_a;
    byte   first_a;
    byte   defaults_a;
    byte   basehost_a;
    byte   apply_a;
    } XIADM02_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm02 = {
    xiadm02_blocks,
    xiadm02_fields,
    71,                                 /*  Number of blocks in form        */
    11,                                 /*  Number of fields in form        */
    6,                                  /*  Number of actions in form       */
    851,                                /*  Size of fields                  */
    "xiadm02",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
