/*---------------------------------------------------------------------------
 *  xiadm21.h - HTML form definition
 *
 *  Generated 1998/04/25,  9:11:48 by fxgen 2.0
 *  See Studio on-line help pages at <http://www.imatix.com>.
 *---------------------------------------------------------------------------*/

#ifndef __FORM_XIADM21__
#define __FORM_XIADM21__

#include "sfl.h"
#include "formio.h"


/*  Constants defining size of tables, etc.                                  */

#define XIADM21_MESSAGE_TO_USER             0
#define XIADM21_REFRESH_ON                  1
#define XIADM21_L_SERVER_MESSAGE            2
#define XIADM21_SERVER_MESSAGE              3
#define XIADM21_L_HTTP_PORT                 4
#define XIADM21_HTTP_PORT                   5
#define XIADM21_L_FTP_PORT                  6
#define XIADM21_FTP_PORT                    7
#define XIADM21_L_CUR_CONNECTS              8
#define XIADM21_CUR_CONNECTS                9
#define XIADM21_L_MAX_CONNECTS              10
#define XIADM21_MAX_CONNECTS                11
#define XIADM21_L_CONNECT_COUNT             12
#define XIADM21_CONNECT_COUNT               13
#define XIADM21_L_ERROR_COUNT               14
#define XIADM21_ERROR_COUNT                 15
#define XIADM21_L_TRANSFER_SIZE             16
#define XIADM21_TRANSFER_SIZE               17

/*  This table contains each block in the form                               */

static byte xiadm21_blocks [] = {
    /*  <HTML><HEAD><TITLE>Server Console Panel</TITLE>                      */
    0, 49, 0, '<', 'H', 'T', 'M', 'L', '>', '<', 'H', 'E', 'A', 'D',
    '>', '<', 'T', 'I', 'T', 'L', 'E', '>', 'S', 'e', 'r', 'v', 'e',
    'r', 32, 'C', 'o', 'n', 's', 'o', 'l', 'e', 32, 'P', 'a', 'n', 'e',
    'l', '<', '/', 'T', 'I', 'T', 'L', 'E', '>', 10,
    /*  </HEAD><BODY onLoad="focus()">                                       */
    0, 32, 0, '<', '/', 'H', 'E', 'A', 'D', '>', '<', 'B', 'O', 'D',
    'Y', 32, 'o', 'n', 'L', 'o', 'a', 'd', '=', '"', 'f', 'o', 'c', 'u',
    's', '(', ')', '"', '>', 10,
    /*  !--IF message_to_user                                                */
    0, 5, 2, 0, 0, 0, 4,
    /*  <P><FONT SIZE=5>                                                     */
    0, 18, 0, '<', 'P', '>', '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z',
    'E', '=', '5', '>', 10,
    /*  !--FIELD TEXTUAL message_to_user SIZE=80                             */
    0, 25, 10, 9, 1, 0, 0, 'P', 0, 'P', 'm', 'e', 's', 's', 'a', 'g',
    'e', '_', 't', 'o', '_', 'u', 's', 'e', 'r', 0, 0,
    /*  <FONT SIZE=3>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3',
    '>', 10,
    /*  <HR>                                                                 */
    0, 6, 0, '<', 'H', 'R', '>', 10,
    /*  <TABLE WIDTH=100%><TR><TD>                                           */
    0, 28, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', '<', 'T', 'R', '>', '<', 'T', 'D',
    '>', 10,
    /*  <FONT SIZE=2><A HREF="#(uri) ... 4.htm">Help</A><FONT SIZE=3>        */
    0, 134, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=',
    '2', '>', '<', 'A', 32, 'H', 'R', 'E', 'F', '=', '"', '#', '(', 'u',
    'r', 'i', ')', '&', '~', 'L', 'm', 'a', 'i', 'n', '=', '1', '"',
    '>', 'M', 'a', 'i', 'n', '<', '/', 'A', '>', 32, '|', 32, '<', 'E',
    'M', '>', 'C', 'o', 'n', 's', 'o', 'l', 'e', '<', '/', 'E', 'M',
    '>', 32, '|', 32, '<', 'A', 32, 'T', 'A', 'R', 'G', 'E', 'T', '=',
    '"', 'H', 'e', 'l', 'p', '"', 32, 'H', 'R', 'E', 'F', '=', '"', 'x',
    'i', 't', 'a', 'm', 'i', '/', 'i', 'n', 'd', 'e', 'x', '4', '.',
    'h', 't', 'm', '"', '>', 'H', 'e', 'l', 'p', '<', '/', 'A', '>',
    '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '3', '>', 10,
    /*  <TD ALIGN=RIGHT>                                                     */
    0, 18, 0, '<', 'T', 'D', 32, 'A', 'L', 'I', 'G', 'N', '=', 'R', 'I',
    'G', 'H', 'T', '>', 10,
    /*  Server Console Panel                                                 */
    0, 22, 0, 'S', 'e', 'r', 'v', 'e', 'r', 32, 'C', 'o', 'n', 's', 'o',
    'l', 'e', 32, 'P', 'a', 'n', 'e', 'l', 10,
    /*  </TABLE>                                                             */
    0, 10, 0, '<', '/', 'T', 'A', 'B', 'L', 'E', '>', 10,
    /*  !--FIELD NUMERIC refresh_on SIZE=4 VALUE=1                           */
    0, 26, 11, 5, 1, 0, 4, 0, 4, 0, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r',
    'e', 's', 'h', '_', 'o', 'n', 0, '1', 0,
    /*  !--IF refresh_on                                                     */
    0, 5, 2, 0, 1, 0, 1,
    /*  <META HTTP-EQUIV="REFRESH" CONTENT="#(rate)">                        */
    0, 47, 0, '<', 'M', 'E', 'T', 'A', 32, 'H', 'T', 'T', 'P', 45, 'E',
    'Q', 'U', 'I', 'V', '=', '"', 'R', 'E', 'F', 'R', 'E', 'S', 'H',
    '"', 32, 'C', 'O', 'N', 'T', 'E', 'N', 'T', '=', '"', '#', '(', 'r',
    'a', 't', 'e', ')', '"', '>', 10,
    /*  <HR>                                                                 */
    0, 4, 1, 0, 0, 156,
    /*  <FORM METHOD=POST ACTION="#(uri)">                                   */
    0, 36, 0, '<', 'F', 'O', 'R', 'M', 32, 'M', 'E', 'T', 'H', 'O', 'D',
    '=', 'P', 'O', 'S', 'T', 32, 'A', 'C', 'T', 'I', 'O', 'N', '=', '"',
    '#', '(', 'u', 'r', 'i', ')', '"', '>', 10,
    /*  <INPUT TYPE=HIDDEN NAME=jsaction VALUE="">                           */
    0, 44, 0, '<', 'I', 'N', 'P', 'U', 'T', 32, 'T', 'Y', 'P', 'E', '=',
    'H', 'I', 'D', 'D', 'E', 'N', 32, 'N', 'A', 'M', 'E', '=', 'j', 's',
    'a', 'c', 't', 'i', 'o', 'n', 32, 'V', 'A', 'L', 'U', 'E', '=', '"',
    '"', '>', 10,
    /*  <TABLE WIDTH=100%>                                                   */
    0, 20, 0, '<', 'T', 'A', 'B', 'L', 'E', 32, 'W', 'I', 'D', 'T', 'H',
    '=', '1', '0', '0', '%', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 39, 0, '<', 'T', 'R', '>', '<', 'T', 'D', 32, 'A', 'L', 'I', 'G',
    'N', '=', 'L', 'E', 'F', 'T', 32, 'V', 'A', 'L', 'I', 'G', 'N', '=',
    'T', 'O', 'P', 32, 'N', 'O', 'W', 'R', 'A', 'P', '>', 10,
    /*  !--FIELD TEXTUAL f291 NAME=L ... Last server error message:"         */
    0, 40, 10, 6, 1, 0, 0, 26, 0, 26, 'f', '2', '9', '1', 0, 'L', 'a',
    's', 't', 32, 's', 'e', 'r', 'v', 'e', 'r', 32, 'e', 'r', 'r', 'o',
    'r', 32, 'm', 'e', 's', 's', 'a', 'g', 'e', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 41, 0, '<', '/', 'T', 'D', '>', '<', 'T', 'D', 32, 'A', 'L', 'I',
    'G', 'N', '=', 'L', 'E', 'F', 'T', 32, 'N', 'O', 'W', 'R', 'A', 'P',
    32, 'W', 'I', 'D', 'T', 'H', '=', '"', '8', '0', '%', '"', '>', 10,
    /*  !--FIELD TEXTUAL f292 NAME=s ... E=80 MAX=? UPPER=0 VALUE=""         */
    0, 14, 10, 0, 1, 0, 0, 'P', 0, 'P', 'f', '2', '9', '2', 0, 0,
    /*  </TD></TR>                                                           */
    0, 12, 0, '<', '/', 'T', 'D', '>', '<', '/', 'T', 'R', '>', 10,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f293 NAME=L ... ="HTTP service is on port:"         */
    0, 38, 10, 6, 1, 0, 0, 24, 0, 24, 'f', '2', '9', '3', 0, 'H', 'T',
    'T', 'P', 32, 's', 'e', 'r', 'v', 'i', 'c', 'e', 32, 'i', 's', 32,
    'o', 'n', 32, 'p', 'o', 'r', 't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f294 NAME=h ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, 'f', '2', '9', '4',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f295 NAME=L ... E="FTP service is on port:"         */
    0, 37, 10, 6, 1, 0, 0, 23, 0, 23, 'f', '2', '9', '5', 0, 'F', 'T',
    'P', 32, 's', 'e', 'r', 'v', 'i', 'c', 'e', 32, 'i', 's', 32, 'o',
    'n', 32, 'p', 'o', 'r', 't', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f296 NAME=f ... MMA=0 SIZE=5 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 5, 0, 5, 0, 0, 0, 0, 0, 0, 'f', '2', '9', '6',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f297 NAME=L ... umber of open connections:"         */
    0, 41, 10, 6, 1, 0, 0, 27, 0, 27, 'f', '2', '9', '7', 0, 'N', 'u',
    'm', 'b', 'e', 'r', 32, 'o', 'f', 32, 'o', 'p', 'e', 'n', 32, 'c',
    'o', 'n', 'n', 'e', 'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f298 NAME=c ... MMA=0 SIZE=6 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, 'f', '2', '9', '8',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f299 NAME=L ... "Highest open connections:"         */
    0, 39, 10, 6, 1, 0, 0, 25, 0, 25, 'f', '2', '9', '9', 0, 'H', 'i',
    'g', 'h', 'e', 's', 't', 32, 'o', 'p', 'e', 'n', 32, 'c', 'o', 'n',
    'n', 'e', 'c', 't', 'i', 'o', 'n', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f300 NAME=m ... MMA=0 SIZE=6 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 6, 0, 6, 0, 0, 0, 0, 0, 0, 'f', '3', '0', '0',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f301 NAME=L ... LUE="Total number of hits:"         */
    0, 35, 10, 6, 1, 0, 0, 21, 0, 21, 'f', '3', '0', '1', 0, 'T', 'o',
    't', 'a', 'l', 32, 'n', 'u', 'm', 'b', 'e', 'r', 32, 'o', 'f', 32,
    'h', 'i', 't', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f302 NAME=c ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, 'f', '3', '0', '2',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f303 NAME=L ... E="Total number of errors:"         */
    0, 37, 10, 6, 1, 0, 0, 23, 0, 23, 'f', '3', '0', '3', 0, 'T', 'o',
    't', 'a', 'l', 32, 'n', 'u', 'm', 'b', 'e', 'r', 32, 'o', 'f', 32,
    'e', 'r', 'r', 'o', 'r', 's', ':', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f304 NAME=e ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, 'f', '3', '0', '4',
    0, 0,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  <TR><TD ALIGN=LEFT VALIGN=TOP NOWRAP>                                */
    0, 4, 1, 0, 2, 'F',
    /*  !--FIELD TEXTUAL f305 NAME=L ... UE="Total data transferred"         */
    0, 36, 10, 6, 1, 0, 0, 22, 0, 22, 'f', '3', '0', '5', 0, 'T', 'o',
    't', 'a', 'l', 32, 'd', 'a', 't', 'a', 32, 't', 'r', 'a', 'n', 's',
    'f', 'e', 'r', 'r', 'e', 'd', 0,
    /*  </TD><TD ALIGN=LEFT NOWRAP WIDTH="80%">                              */
    0, 4, 1, 0, 2, 153,
    /*  !--FIELD NUMERIC f306 NAME=t ... MA=0 SIZE=10 MAX=? VALUE=""         */
    0, 19, 11, 0, 1, 0, 10, 0, 10, 0, 0, 0, 0, 0, 0, 'f', '3', '0', '6',
    0, 0,
    /*  Kb                                                                   */
    0, 4, 0, 'K', 'b', 10,
    /*  </TD></TR>                                                           */
    0, 4, 1, 0, 2, 212,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'v',
    /*  <P>                                                                  */
    0, 5, 0, '<', 'P', '>', 10,
    /*  !--ACTION messages  LABEL="M ... =messages_event TYPE=BUTTON         */
    0, 32, 20, 0, (byte) ((word) messages_event / 256), (byte) ((word)
    messages_event & 255), 0, 0, 0, 0, 0, 0, 0, 'm', 'e', 's', 's', 'a',
    'g', 'e', 's', 0, 'M', 'e', 's', 's', 'a', 'g', 'e', 's', '.', '.',
    '.', 0,
    /*  !--ACTION details  LABEL="De ... T=details_event TYPE=BUTTON         */
    0, 30, 20, 0, (byte) ((word) details_event / 256), (byte) ((word)
    details_event & 255), 0, 1, 0, 0, 0, 0, 0, 'd', 'e', 't', 'a', 'i',
    'l', 's', 0, 'D', 'e', 't', 'a', 'i', 'l', 's', '.', '.', '.', 0,
    /*  !--ACTION properties  LABEL= ... NT=define_event TYPE=BUTTON         */
    0, 36, 20, 0, (byte) ((word) define_event / 256), (byte) ((word)
    define_event & 255), 0, 2, 0, 0, 0, 0, 0, 'p', 'r', 'o', 'p', 'e',
    'r', 't', 'i', 'e', 's', 0, 'P', 'r', 'o', 'p', 'e', 'r', 't', 'i',
    'e', 's', '.', '.', '.', 0,
    /*  !--ACTION refresh  LABEL="Re ... T=refresh_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) refresh_event / 256), (byte) ((word)
    refresh_event & 255), 0, 3, 0, 0, 0, 0, 0, 'r', 'e', 'f', 'r', 'e',
    's', 'h', 0, 'R', 'e', 'f', 'r', 'e', 's', 'h', 0,
    /*  !--ACTION clear  LABEL="Clear" EVENT=clear_event TYPE=BUTTON         */
    0, 23, 20, 0, (byte) ((word) clear_event / 256), (byte) ((word)
    clear_event & 255), 0, 4, 0, 0, 0, 0, 0, 'c', 'l', 'e', 'a', 'r', 0,
    'C', 'l', 'e', 'a', 'r', 0,
    /*  !--ACTION restart  LABEL="Re ... T=restart_event TYPE=BUTTON         */
    0, 27, 20, 0, (byte) ((word) restart_event / 256), (byte) ((word)
    restart_event & 255), 0, 5, 0, 0, 0, 0, 0, 'r', 'e', 's', 't', 'a',
    'r', 't', 0, 'R', 'e', 's', 't', 'a', 'r', 't', 0,
    /*  !--ACTION terminate  LABEL=" ... VENT=kill_event TYPE=BUTTON         */
    0, 31, 20, 0, (byte) ((word) kill_event / 256), (byte) ((word)
    kill_event & 255), 0, 6, 0, 0, 0, 0, 0, 't', 'e', 'r', 'm', 'i',
    'n', 'a', 't', 'e', 0, 'T', 'e', 'r', 'm', 'i', 'n', 'a', 't', 'e',
    0,
    /*  </FORM>                                                              */
    0, 9, 0, '<', '/', 'F', 'O', 'R', 'M', '>', 10,
    /*  <SCRIPT>                                                             */
    0, 10, 0, '<', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  function submit(arguments) { ... forms[0].#(_focus).focus();}        */
    0, 202, 0, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 's', 'u',
    'b', 'm', 'i', 't', '(', 'a', 'r', 'g', 'u', 'm', 'e', 'n', 't',
    's', ')', 32, '{', 10, 10, 'd', 'o', 'c', 'u', 'm', 'e', 'n', 't',
    '.', 'f', 'o', 'r', 'm', 's', '[', '0', ']', '.', 'j', 's', 'a',
    'c', 't', 'i', 'o', 'n', '.', 'v', 'a', 'l', 'u', 'e', 32, '=', 32,
    'a', 'r', 'g', 'u', 'm', 'e', 'n', 't', 's', ';', 10, 10, 'd', 'o',
    'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's', '[',
    '0', ']', '.', 's', 'u', 'b', 'm', 'i', 't', '(', ')', ';', 10, 10,
    '}', 10, 10, 'f', 'u', 'n', 'c', 't', 'i', 'o', 'n', 32, 'f', 'o',
    'c', 'u', 's', '(', ')', 32, '{', 10, 10, 'i', 'f', 32, '(', '"',
    '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')', '"', 32, '!', '=', 32,
    '"', 'j', 's', 'a', 'c', 't', 'i', 'o', 'n', '"', ')', 10, 10, 'd',
    'o', 'c', 'u', 'm', 'e', 'n', 't', '.', 'f', 'o', 'r', 'm', 's',
    '[', '0', ']', '.', '#', '(', '_', 'f', 'o', 'c', 'u', 's', ')',
    '.', 'f', 'o', 'c', 'u', 's', '(', ')', ';', 10, 10, '}', 10,
    /*  </SCRIPT>                                                            */
    0, 11, 0, '<', '/', 'S', 'C', 'R', 'I', 'P', 'T', '>', 10,
    /*  <FONT SIZE=2>                                                        */
    0, 15, 0, '<', 'F', 'O', 'N', 'T', 32, 'S', 'I', 'Z', 'E', '=', '2',
    '>', 10,
    /*  Copyright &#169 1997-98 iMatix<BR>Powered by iMatix Studio 1.0       */
    0, 64, 0, 'C', 'o', 'p', 'y', 'r', 'i', 'g', 'h', 't', 32, '&', '#',
    '1', '6', '9', 32, '1', '9', '9', '7', 45, '9', '8', 32, 'i', 'M',
    'a', 't', 'i', 'x', '<', 'B', 'R', '>', 'P', 'o', 'w', 'e', 'r',
    'e', 'd', 32, 'b', 'y', 32, 'i', 'M', 'a', 't', 'i', 'x', 32, 'S',
    't', 'u', 'd', 'i', 'o', 32, '1', '.', '0', 10,
    /*  </TABLE>                                                             */
    0, 4, 1, 0, 1, 'v',
    /*  </BODY></HTML>                                                       */
    0, 16, 0, '<', '/', 'B', 'O', 'D', 'Y', '>', '<', '/', 'H', 'T',
    'M', 'L', '>', 10,
    0, 0, 0
    };

static FIELD_DEFN xiadm21_fields [] = {
    { 0, 112, 80 },                     /*  message_to_user                 */
    { 82, 386, 4 },                     /*  refresh_on                      */
    { 88, 623, 26 },                    /*  l_server_message                */
    { 116, 708, 80 },                   /*  server_message                  */
    { 198, 744, 24 },                   /*  l_http_port                     */
    { 224, 790, 5 },                    /*  http_port                       */
    { 231, 823, 23 },                   /*  l_ftp_port                      */
    { 256, 868, 5 },                    /*  ftp_port                        */
    { 263, 901, 27 },                   /*  l_cur_connects                  */
    { 292, 950, 6 },                    /*  cur_connects                    */
    { 300, 983, 25 },                   /*  l_max_connects                  */
    { 327, 1030, 6 },                   /*  max_connects                    */
    { 335, 1063, 21 },                  /*  l_connect_count                 */
    { 358, 1106, 10 },                  /*  connect_count                   */
    { 370, 1139, 23 },                  /*  l_error_count                   */
    { 395, 1184, 10 },                  /*  error_count                     */
    { 407, 1217, 22 },                  /*  l_transfer_size                 */
    { 431, 1261, 10 },                  /*  transfer_size                   */
    { 443, 0, 0 },                      /*  -- sentinel --                  */
    };

/*  The data of a form is a list of attributes and fields                    */

typedef struct {
    byte   message_to_user_a    ;
    char   message_to_user      [80 + 1];
    byte   refresh_on_a         ;
    char   refresh_on           [4 + 1];
    byte   l_server_message_a   ;
    char   l_server_message     [26 + 1];
    byte   server_message_a     ;
    char   server_message       [80 + 1];
    byte   l_http_port_a        ;
    char   l_http_port          [24 + 1];
    byte   http_port_a          ;
    char   http_port            [5 + 1];
    byte   l_ftp_port_a         ;
    char   l_ftp_port           [23 + 1];
    byte   ftp_port_a           ;
    char   ftp_port             [5 + 1];
    byte   l_cur_connects_a     ;
    char   l_cur_connects       [27 + 1];
    byte   cur_connects_a       ;
    char   cur_connects         [6 + 1];
    byte   l_max_connects_a     ;
    char   l_max_connects       [25 + 1];
    byte   max_connects_a       ;
    char   max_connects         [6 + 1];
    byte   l_connect_count_a    ;
    char   l_connect_count      [21 + 1];
    byte   connect_count_a      ;
    char   connect_count        [10 + 1];
    byte   l_error_count_a      ;
    char   l_error_count        [23 + 1];
    byte   error_count_a        ;
    char   error_count          [10 + 1];
    byte   l_transfer_size_a    ;
    char   l_transfer_size      [22 + 1];
    byte   transfer_size_a      ;
    char   transfer_size        [10 + 1];
    byte   messages_a;
    byte   details_a;
    byte   properties_a;
    byte   refresh_a;
    byte   clear_a;
    byte   restart_a;
    byte   terminate_a;
    } XIADM21_DATA;

/*  The form definition collects these tables into a header                  */

static FORM_DEFN form_xiadm21 = {
    xiadm21_blocks,
    xiadm21_fields,
    77,                                 /*  Number of blocks in form        */
    18,                                 /*  Number of fields in form        */
    7,                                  /*  Number of actions in form       */
    443,                                /*  Size of fields                  */
    "xiadm21",                          /*  Name of form                    */
    };

#endif                                  /*  End included file               */
