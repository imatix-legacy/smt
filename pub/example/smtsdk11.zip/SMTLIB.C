/*===========================================================================*
 *                                                                           *
 *  smtlib.c    LIBERO Simple Multithreading (SMT) functions                 *
 *                                                                           *
 *  Written:    96/02/04  Pieter Hintjens                                    *
 *  Revised:    96/03/28                                                     *
 *                                                                           *
 *  Usage:      Must be linked with programs based on LRTHREAD.C.            *
 *                                                                           *
 *  Author:     Pieter A. Hintjens                                           *
 *              Pijlstraat 9                                                 *
 *              2060 Antwerpen, Belgium                                      *
 *              ph@mymail.com                                                *
 *              (+323) 231.5277                                              *
 *                                                                           *
 *  FSM Code Generator.  Copyright (c) 1991-95 Pieter A. Hintjens.           *
 *                                                                           *
 *  This program is free software; you can redistribute it and/or modify     *
 *  it under the terms of the GNU General Public License as published by     *
 *  the Free Software Foundation; either version 2 of the License, or        *
 *  (at your option) any later version.                                      *
 *                                                                           *
 *  This program is distributed in the hope that it will be useful,          *
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of           *
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the            *
 *  GNU General Public License for more details.                             *
 *                                                                           *
 *  You should have received a copy of the GNU General Public License        *
 *  along with this program; if not, write to the Free Software              *
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.                *
 *===========================================================================*/

#include "prelude.h"                    /*  Universal include file           */
#include "smtlib.h"                     /*  Prototypes for these functions   */
#include "sockio.h"                     /*  Socket i/o functions             */

local init_library      (void);
local handle_signal     (int the_signal);

/*  All dialogs attached here                                                */
static _DIB
    dialog_list = { &dialog_list, &dialog_list };

/*  We cache released blocks to reduce calls to malloc/free                  */
/*  In practice the same blocks are used over and over again.                */
static _TIB
    tib_pool = { &tib_pool, &tib_pool };
static _MIB
    mib_pool = { &mib_pool, &mib_pool };

static Bool
    critical_section = FALSE;           /*  When we are changing a list      */

long
    malloc_count = 0,
    free_count = 0;


/*  -------------------------------------------------------------------------
 *  _DIB_create
 *
 *  Create a new DIB and initialise it.  Returns a pointer to the newly-
 *  created DIB, or NULL if there was not enough memory.  Sets the DIB to
 *  all binary zeroes, except the lists which are initialised with a single
 *  header item (empty lists contain just the header item).
 */

_DIB *
_DIB_create (void)
{
    static Bool
        first_time = TRUE;              /*  First time flag                  */
    _DIB
        *dib;

    if (first_time)
      {
        first_time = FALSE;
        init_library ();                /*  Initialise the library           */
      }
    if ((dib = (_DIB *) malloc (sizeof (_DIB))) != NULL)
      {
        malloc_count++;
        memset (dib, 0, sizeof (_DIB));
        dib-> next =                    /*  Initialise DIB pointers          */
        dib-> prev = dib;

        dib-> active   = _TIB_create ();
        dib-> passive  = _TIB_create ();
        dib-> io_set   = (_TIB **) malloc (FD_SETSIZE * sizeof (_TIB *));
        dib-> messages = _MIB_create ();
        malloc_count++;
      }
    _DIB_relink_before (dib, &dialog_list);
    return (dib);                       /*  Return allocated DIB, or NULL    */
}


/*  -------------------------------------------------------------------------
 *  init_library
 *
 *  - trap signals
 */

local
init_library (void)
{
    signal (SIGINT,  handle_signal);
    signal (SIGTERM, handle_signal);
    signal (SIGSEGV, handle_signal);

#if defined (SIGPIPE)
    /*  On some systems we get a 'broken pipe' when a connection fails       */
    signal (SIGPIPE, SIG_IGN);
#endif
}


/*  -------------------------------------------------------------------------
 *  handle_signal
 *
 *  Sets all dialog signal_raised flags to TRUE, and signal_handled to FALSE.
 *  The dialog is expected to handle the signal during its next iteration.
 */

local
handle_signal (int the_signal)
{
    _DIB
        *dib;

    if (!critical_section)
      {
        signal (SIGINT,  SIG_IGN);
        signal (SIGTERM, SIG_IGN);
        signal (SIGSEGV, SIG_IGN);

        for (dib = dialog_list.next; dib != &dialog_list; dib = dib-> next)
            _DIB_shutdown (dib, the_signal);
      }
}


/*  -------------------------------------------------------------------------
 *  _DIB_destroy
 *
 *  Destroys the DIB - destroys the dialog's lists, then frees the memory
 *  used by the DIB.
 */

void
_DIB_destroy (_DIB *dib)
{
    /*  Destroy dialog list items                                            */
    while (dib-> active-> next != dib-> active)
        _DIB_thread_destroy (dib, dib-> active-> next);

    while (dib-> passive-> next != dib-> passive)
        _DIB_thread_destroy (dib, dib-> passive-> next);

    while (dib-> messages-> next != dib-> messages)
        _DIB_message_destroy (dib, dib-> messages-> next);

    /*  Destroy dialog list headers                                          */
    _TIB_destroy (dib-> active);
    _TIB_destroy (dib-> passive);
    _MIB_destroy (dib-> messages);

    /*  Destroy TIB cache pool blocks until the pool is empty                */
    while (tib_pool.next != &tib_pool)
      {
        free (_TIB_unlink (tib_pool.next));
        free_count++;
      }
    /*  Destroy MIB cache pool blocks until the pool is empty                */
    while (mib_pool.next != &mib_pool)
      {
        free (_MIB_unlink (mib_pool.next));
        free_count++;
      }

    if (dib-> io_set)                   /*  Free I/O set if allocated        */
      {
        free (dib-> io_set);
        free_count++;
        dib-> io_set = NULL;
      }
    free (dib);
    free_count++;
}


/*  -------------------------------------------------------------------------
 *  _DIB_unlink
 *
 *  Removes specified DIB from list; the DIB is left with prev and next
 *  pointers pointing to itself.  Returns pointer to DIB.
 */

_DIB *
_DIB_unlink (_DIB *dib)
{
    _DIB_relink (dib-> prev, dib, dib-> next);
    return (dib);
}


/*  -------------------------------------------------------------------------
 *  _DIB_relink_after
 *
 *  Inserts the specified DIB after dest.  Returns pointer to DIB.
 */

_DIB *
_DIB_relink_after (_DIB *dib, _DIB *dest)
{
    _DIB_relink (dest, dib, dest-> next);
    return (dib);
}


/*  -------------------------------------------------------------------------
 *  _DIB_relink_before
 *
 *  Inserts the specified DIB before dest.  Returns pointer to DIB.
 */

_DIB *
_DIB_relink_before (_DIB *dib, _DIB *dest)
{
    _DIB_relink (dest-> prev, dib, dest);
    return (dib);
}


/*  -------------------------------------------------------------------------
 *  _DIB_relink
 *
 *  Links or unlinks DIB by exchanging pointers with left and right DIBs.
 *  General-purpose function for building linked-list of DIBs.
 */

void
_DIB_relink (_DIB *left, _DIB *dib, _DIB *right)
{
    _DIB *swap;

    critical_section = TRUE;

    swap = left-> next;                 /*  Exchange left pointers           */
           left-> next = dib-> next;
                         dib-> next = swap;
    swap = right-> prev;                /*  Exchange right pointers          */
           right-> prev = dib-> prev;
                          dib-> prev = swap;

    critical_section = FALSE;
}


/*  -------------------------------------------------------------------------
 *  _DIB_thread_create
 *
 *  Creates a new dialog thread, on the specified list.  You must allocate
 *  the TCB and module call stack if required, and execute the user startup
 *  function (initialise_the_thread) after calling this function.
 *
 *  Returns the address of the newly-created TIB, or null if it could not
 *  create the thread (due to lack of memory).  The thread is created with
 *  all fields in the TIB set to binary zeroes, except the list pointers.
 */

_TIB *
_DIB_thread_create (_DIB *dib, _TIB *list)
{
    _TIB *tib;                          /*  Thread information block         */

    /*  Attach new tib to specified list                                     */
    tib = _TIB_create ();
    if (tib)
      {                                 /*  Add to end of of active list     */
        _TIB_relink_before (tib, list);
        tib-> thread_id = ++dib-> count_create_threads;
        dib-> total_threads++;          /*  Thread now exists officially     */
        if (dib-> max_total_threads < dib-> total_threads)
            dib-> max_total_threads = dib-> total_threads;
      }
    return (tib);
}


/*  -------------------------------------------------------------------------
 *  _DIB_thread_destroy
 *
 *  Removes a thread from a list and destroys it.  You must call the user
 *  shutdown procedure.  Deallocates the TCB and stack if used.  The thread
 *  may be linked or unlinked.
 */

void
_DIB_thread_destroy (_DIB *dib, _TIB *tib)
{
    if (tib-> tcb)                      /*  Free TCB if allocated            */
      {
        free (tib-> tcb);
        free_count++;
        tib-> tcb = NULL;
      }
    if (tib-> _LR_stack)                /*  Free stack if allocated          */
      {
        free (tib-> _LR_stack);
        free_count++;
        tib-> _LR_stack = NULL;
      }
    _TIB_destroy (_TIB_unlink (tib));
    dib-> total_threads--;              /*  Thread is now destroyed          */
}


/*  -------------------------------------------------------------------------
 *  _DIB_message_create
 *
 *  Creates a new dialog message as specified.  If the message is 'weak'
 *  (strong = FALSE), the message is not created if a previous message
 *  already exists with the same ident.  Returns the address of the MIB
 *  or null if it could not create the message.  Rejects any messages
 *  when the dialog is shutting-down (dib-> signal_handled is true).
 */

_MIB *
_DIB_message_create (
    _DIB  *dib,                         /*  Current dialog                   */
    _TIB  *tib,                         /*  Thread recipient, or NULL        */
    long   ident,                       /*  Message identifier               */
    char  *body,                        /*  Message body, or NULL            */
    dbyte   size,                        /*  Size of message body, or 0       */
    Bool   strong)                      /*  Strong message?                  */
{
    _MIB
        *mib;                           /*  Message information block        */

    if (dib-> signal_handled)           /*  Dialog is shutting-down          */
        return (NULL);                  /*    -- reject message              */

    /*  Look for equivalent message, if weak                                 */
    if (!strong)
      {
        for (mib  = dib-> messages-> next;
             mib != dib-> messages;
             mib  = mib-> next)
            if (mib-> ident == ident)
              {
                dib-> check_messages = TRUE;
                return (mib);           /*  Found message with same ident    */
              }
      }
    /*  Attach new message to dialog's message list                          */
    mib = _MIB_create ();
    if (mib)
      {
        ASSERT (dib-> total_messages < MAX_MESSAGES);
        _MIB_relink_before (mib, dib-> messages);
        mib-> ident = ident;
        mib-> tib   = tib;
        mib-> size  = size;
        if (mib-> size > MAX_MSGBODY)
            mib-> size = MAX_MSGBODY;
        memcpy (mib-> body, body, mib-> size);

        dib-> count_create_messages++;  /*  Keep dialog statistics           */
        dib-> total_messages++;         /*  Message now exists officially    */
        if (dib-> max_total_messages < dib-> total_messages)
            dib-> max_total_messages = dib-> total_messages;
      }
    dib-> check_messages = TRUE;
    return (mib);
}


/*  -------------------------------------------------------------------------
 *  _DIB_message_destroy
 *
 *  Removes a message from a list and destroys it. The message may be linked
 */

void
_DIB_message_destroy (_DIB *dib, _MIB *mib)
{
    _MIB_destroy (_MIB_unlink (mib));
    dib-> total_messages--;             /*  Message is now destroyed         */
}


/*  -------------------------------------------------------------------------
 *  _DIB_expect_message
 *
 *  Prepares a thread to wait for a specified message.  The thread will be
 *  suspended until that message arrives.  If the message ident is zero,
 *  any previous wait is cancelled.
 */

void
_DIB_expect_message (
    _DIB *dib,                          /*  Current dialog                   */
    _TIB *tib,                          /*  Thread that will wait            */
    long ident)                         /*  Message to wait for              */
{
    tib-> wait_message   = ident;       /*  Message identifier, or zero      */
    dib-> suspend_thread = TRUE;        /*  We want to suspend the thread    */
    dib-> check_messages = TRUE;        /*  Re-check messages                */
}


/*  -------------------------------------------------------------------------
 *  _DIB_expect_io
 *
 *  Prepares a thread for i/o on a (socket) handle.  The thread will be
 *  suspended until input or output (as specified) or an error occurs on
 *  the specified handle.
 */

void
_DIB_expect_io (_DIB *dib, _TIB *tib, SOCKET handle, char readwrite)
{
    /*  Remove the next 2 lines after 96/12/31                               */
    if (handle < 1 || handle >= FD_SETSIZE)
        printf ("Handle=%d Thread=%ld\n", handle, tib-> thread_id);
    ASSERT (handle > 0 && handle < FD_SETSIZE);

    FD_SET (handle, (readwrite == 'r'? &dib-> read_set: &dib-> write_set));
    FD_SET (handle, &dib-> error_set);
    if (dib-> max_socket < handle)      /*  Keep track of highest handle     */
        dib-> max_socket = handle;

    dib-> io_set [handle] = tib;        /*  And store requesting thread      */
    dib-> suspend_thread  = TRUE;       /*  We want to suspend the thread    */
    dib-> count_io_requests++;          /*  Keep dialog statistics           */
}


/*  -------------------------------------------------------------------------
 *  _DIB_regen_messages
 *
 *  Generate any internal messages that are pending; i.e. input or output
 *  on an asynchronous (socket) handle, or a timing message.
 *
 *  May generate these internal messages:
 *
 *      MSG_INPUT_READY     Some input arrived on a handle
 *      MSG_OUTPUT_READY    A handle is ready for output
 *      MSG_IO_ERROR        An error occurred on a handle
 *
 *  Implementation:
 *      Uses the select() function to check every handle on which asynch
 *      I/O was asked for.  Any I/O on a handle clears all other I/O bits
 *      on the same handle.
 */

void
_DIB_regen_messages (_DIB *dib)
{
    static fd_set
        read_set,                       /*  Set of handles for select()      */
        write_set,
        error_set;
    static struct timeval
        timeout = { 0, 0 };             /*  Timeout for select()             */
    int
        rc;                             /*  Return code from select()        */
    SOCKET
        handle;                         /*  Scan through fd_sets             */
    long
        message;                        /*  Message to generate              */

    memcpy (&read_set,  &dib-> read_set,  sizeof (fd_set));
    memcpy (&write_set, &dib-> write_set, sizeof (fd_set));
    memcpy (&error_set, &dib-> error_set, sizeof (fd_set));

    /*  Timeout is 0 seconds if there are active threads or fresh messages,  */
    /*  else 1 second; this gives timing events an accuracy of 1 second.     */
    /*  Note: timing events are not yet implemented.                         */

    if (dib-> active-> next != dib-> active || dib-> check_messages)
        timeout.tv_sec = 0;
    else
        timeout.tv_sec = 1;

    rc = select (dib-> max_socket + 1,       /*  Handles to check            */
                 FD_SETTYPE &read_set,       /*  Check for input             */
                 FD_SETTYPE &write_set,      /*  Check for output            */
                 FD_SETTYPE &error_set,      /*  Check for errors            */
                 &timeout);                  /*  Timeout                     */
    if (rc > 0)
        /*  Any bits set indicate ready for input, output, or an error       */
        for (handle = 0; handle < dib-> max_socket + 1; handle++)
          {
            if (FD_ISSET (handle, &read_set))
                message = MSG_INPUT_READY;
            else
            if (FD_ISSET (handle, &write_set))
                message = MSG_OUTPUT_READY;
            else
            if (FD_ISSET (handle, &error_set))
                message = MSG_IO_ERROR;
            else
                continue;

            /*  Clear all outstanding i/o requests for this handle           */
            FD_CLR (handle, &dib-> read_set);
            FD_CLR (handle, &dib-> write_set);
            FD_CLR (handle, &dib-> error_set);

            /*  And create a message to activate the thread                  */
            _DIB_message_create (
                dib,                    /*  Dialog                           */
                dib-> io_set [handle],  /*  Thread to receive message        */
                message,                /*  Message identifier               */
                NULL, 0,                /*  Message body size and address    */
                TRUE                    /*  Strong message                   */
            );
          }
}


/*  -------------------------------------------------------------------------
 *  _DIB_deliver_messages
 *
 *   Deliver outstanding messages to the appropriate threads.  When a thread
 *   receives a message it is moved from the passive list to the active list.
 *   By design, only passive list threads can receive messages.  The check_
 *   messages flag is set FALSE when no messages could be delivered.
 */

void
_DIB_deliver_messages (_DIB *dib)
{
    _MIB
        *mib,                           /*  Message information block        */
        *mibnext;                       /*  Next MIB in list                 */
    _TIB
        *tib,                           /*  Thread information block         */
        *tibcheck;                      /*  Look for TIB in list             */

    dib-> check_messages = FALSE;       /*  Assume we deliver none           */
    for (mib = dib-> messages-> next; mib != dib-> messages; )
      {
        mibnext = mib-> next;
        tib     = mib-> tib;            /*  Does message specify a TIB?      */
        if (!tib)                       /*  No - go and look for one         */
          {
            for (tibcheck  = dib-> passive-> next;
                 tibcheck != dib-> passive;
                 tibcheck  = tibcheck-> next)
              {
                if (mib-> ident == tibcheck-> wait_message)
                  {
                    tib = tibcheck;
                    break;
                  }
              }
          }
        /*  Move thread to active list                                       */
        if (tib)
          {
            _TIB_unlink        (tib);
            _TIB_relink_before (tib, dib-> active);
            tib-> wait_message  = 0;
            tib-> message_ident = mib-> ident;
            tib-> message_size  = mib-> size;
            memcpy (tib-> message_body, mib-> body, mib-> size);
            _DIB_message_destroy (dib, mib);
            dib-> check_messages = TRUE;
          }
        mib = mibnext;
      }
}


/*  -------------------------------------------------------------------------
 *  _DIB_lazy_creat
 *
 *  Calls the creat() function without blocking.  Returns a file handle
 *  when the call succeeds, -1 when the call fails, for whatever reason.
 *  Sets the dialog variable io_completed TRUE if the I/O completed,
 *  successfully or not.  We use open() so that we can force O_NONBLOCK.
 */

int
_DIB_lazy_creat (_DIB *dib, char *path, int mode)
{
    int
        rc;

    rc = open (path, O_CREAT | O_WRONLY | O_TRUNC | O_NONBLOCK, mode);
    dib-> io_completed = (rc >= 0 || errno != EAGAIN);
    return (rc);
}


/*  -------------------------------------------------------------------------
 *  _DIB_lazy_open
 *
 *  Calls the open() function without blocking.  Returns a file handle
 *  when the call succeeds, -1 when the call fails, for whatever reason.
 *  Sets the dialog variable io_completed TRUE if the I/O completed,
 *  successfully or not.
 */

int
_DIB_lazy_open (_DIB *dib, char *path, int flags)
{
    int
        rc;

    rc = open (path, flags | O_NONBLOCK, S_IREAD | S_IWRITE);
    dib-> io_completed = (rc >= 0 || errno != EAGAIN);
    return (rc);
}


/*  -------------------------------------------------------------------------
 *  _DIB_lazy_read
 *
 *  Calls the read() function without blocking.  Returns the number of bytes
 *  read when the call succeeds, -1 when the call fails, for whatever reason.
 *  Sets the dialog variable io_completed TRUE if the I/O completed,
 *  successfully or not.
 */

int
_DIB_lazy_read (_DIB *dib, int handle, char *buffer, size_t count)
{
    int
        rc;

    rc = read (handle, buffer, count);
    dib-> io_completed = (rc >= 0 || errno != EAGAIN);
    return (rc);
}


/*  -------------------------------------------------------------------------
 *  _DIB_lazy_write
 *
 *  Calls the write() function without blocking.  Returns the number of bytes
 *  read when the call succeeds, -1 when the call fails, for whatever reason.
 *  Sets the dialog variable io_completed TRUE if the I/O completed,
 *  successfully or not.
 */

int
_DIB_lazy_write (_DIB *dib, int handle, char *buffer, size_t count)
{
    int
        rc;

    rc = write (handle, buffer, count);
    dib-> io_completed = (rc >= 0 || errno != EAGAIN);
    return (rc);
}


/*  -------------------------------------------------------------------------
 *  _DIB_lazy_close
 *
 *  Calls the close() function without blocking.  Returns 0 on success, -1
 *  when the call fails, for whatever reason.  Sets the dialog variable
 *  io_completed TRUE if the I/O completed, successfully or not.
 */

int
_DIB_lazy_close (_DIB *dib, int handle)
{
    int
        rc;

    rc = close (handle);
    dib-> io_completed = (rc >= 0 || errno != EAGAIN);
    return (rc);
}


/*  -------------------------------------------------------------------------
 *  _DIB_shutdown
 *
 *  Sets a dialog's shutdown flags; this effectively kills the dialog.
 *  The signal must come either from the signal handler or be SIG_USER.
 */

void
_DIB_shutdown (_DIB *dib, int the_signal)
{
    dib-> signal_raised  = TRUE;
    dib-> signal_handled = FALSE;
    dib-> signal_value   = the_signal;
}


/*  -------------------------------------------------------------------------
 *  _TIB_create
 *
 *  Create a new TIB and initialise it.  Returns a pointer to the newly-
 *  created TIB, or NULL if there was not enough memory.  Sets the TIB to
 *  all binary zeroes, except the next and prev pointers, which point back
 *  to the newly-created TIB.  All other pointers are initialised to NULL.
 */

_TIB *
_TIB_create (void)
{
    _TIB
        *tib;

    if (tib_pool.next != &tib_pool)
        tib = _TIB_unlink (tib_pool.next);
    else
    if ((tib = (_TIB *) malloc (sizeof (_TIB))) != NULL)
        malloc_count++;

    if (tib)
      {
        memset (tib, 0, sizeof (_TIB));
        tib-> next =                    /*  Initialise TIB pointers          */
        tib-> prev       = tib;
        tib-> _LR_vecptr = NULL;
        tib-> _LR_stack  = NULL;
        tib-> tcb        = NULL;
      }
    return (tib);                       /*  Return allocated TIB, or NULL    */
}


/*  -------------------------------------------------------------------------
 *  _TIB_destroy
 *
 *  Destroys the TIB, by moving to the tib_pool.  Any subsidiary blocks must
 *  already have been freed.  The TIB must already be correctly unlinked.
 */

void
_TIB_destroy (_TIB *tib)
{
    _TIB_relink_after (tib, &tib_pool);
}


/*  -------------------------------------------------------------------------
 *  _TIB_unlink
 *
 *  Removes specified TIB from list; the TIB is left with prev and next
 *  pointers pointing to itself.  Returns pointer to TIB.
 */

_TIB *
_TIB_unlink (_TIB *tib)
{
    _TIB_relink (tib-> prev, tib, tib-> next);
    return (tib);
}


/*  -------------------------------------------------------------------------
 *  _TIB_relink_after
 *
 *  Inserts the specified TIB after dest.  Returns pointer to TIB.
 */

_TIB *
_TIB_relink_after (_TIB *tib, _TIB *dest)
{
    _TIB_relink (dest, tib, dest-> next);
    return (tib);
}


/*  -------------------------------------------------------------------------
 *  _TIB_relink_before
 *
 *  Inserts the specified TIB before dest.  Returns pointer to TIB.
 */

_TIB *
_TIB_relink_before (_TIB *tib, _TIB *dest)
{
    _TIB_relink (dest-> prev, tib, dest);
    return (tib);
}


/*  -------------------------------------------------------------------------
 *  _TIB_relink
 *
 *  Links or unlinks TIB by exchanging pointers with left and right TIBs.
 *  General-purpose function for building linked-list of TIBs.
 */

void
_TIB_relink (_TIB *left, _TIB *tib, _TIB *right)
{
    _TIB *swap;

    critical_section = TRUE;

    swap = left-> next;                 /*  Exchange left pointers           */
           left-> next = tib-> next;
                         tib-> next = swap;
    swap = right-> prev;                /*  Exchange right pointers          */
           right-> prev = tib-> prev;
                          tib-> prev = swap;

    critical_section = FALSE;
}


/*  -------------------------------------------------------------------------
 *  _MIB_create
 *
 *  Create a new MIB and initialise it.  Returns a pointer to the newly-
 *  created MIB, or NULL if there was not enough memory.  Sets the MIB to
 *  all binary zeroes, except the next and prev pointers, which point back
 *  to the newly-created MIB.  All other pointers are set to NULL.
 */

_MIB *
_MIB_create (void)
{
    _MIB
        *mib;

    if (mib_pool.next != &mib_pool)
        mib = _MIB_unlink (mib_pool.next);
    else
    if ((mib = (_MIB *) malloc (sizeof (_MIB))) != NULL)
        malloc_count++;

    if (mib)
      {
        memset (mib, 0, sizeof (_MIB));
        mib-> next =                    /*  Initialise MIB pointers          */
        mib-> prev = mib;
        mib-> tib  = NULL;
      }
    return (mib);                       /*  Return allocated MIB, or NULL    */
}


/*  -------------------------------------------------------------------------
 *  _MIB_destroy
 *
 *  Destroys the MIB by moving to the dib_pool.  Any subsidiary blocks must
 *  already have been freed.  The MIB must already be correctly unlinked.
 */

void
_MIB_destroy (_MIB *mib)
{
    _MIB_relink_after (mib, &mib_pool);
}


/*  -------------------------------------------------------------------------
 *  _MIB_unlink
 *
 *  Removes specified MIB from list; the MIB is left with prev and next
 *  pointers pointing to itself.  Returns pointer to MIB.
 */

_MIB *
_MIB_unlink (_MIB *mib)
{
    _MIB_relink (mib-> prev, mib, mib-> next);
    return (mib);
}


/*  -------------------------------------------------------------------------
 *  _MIB_relink_after
 *
 *  Inserts the specified MIB after dest.  Returns pointer to MIB.
 */

_MIB *
_MIB_relink_after (_MIB *mib, _MIB *dest)
{
    _MIB_relink (dest, mib, dest-> next);
    return (mib);
}


/*  -------------------------------------------------------------------------
 *  _MIB_relink_before
 *
 *  Inserts the specified MIB before dest.  Returns pointer to MIB.
 */

_MIB *
_MIB_relink_before (_MIB *mib, _MIB *dest)
{
    _MIB_relink (dest-> prev, mib, dest);
    return (mib);
}


/*  -------------------------------------------------------------------------
 *  _MIB_relink
 *
 *  Links or unlinks MIB by exchanging pointers with left and right MIBs.
 *  General-purpose function for building linked-list of MIBs.
 */

void
_MIB_relink (_MIB *left, _MIB *mib, _MIB *right)
{
    _MIB *swap;

    critical_section = TRUE;

    swap = left-> next;                 /*  Exchange left pointers           */
           left-> next = mib-> next;
                         mib-> next = swap;
    swap = right-> prev;                /*  Exchange right pointers          */
           right-> prev = mib-> prev;
                          mib-> prev = swap;

    critical_section = FALSE;
}
