/*===========================================================================*
 *                                                                           *
 *  sockio.c    TCP/IP, UDP/IP socket functions                              *
 *                                                                           *
 *  Written:    96/02/03    Pieter Hintjens                                  *
 *  Revised:    96/03/28                                                     *
 *                                                                           *
 *  Author:     Pieter A. Hintjens                                           *
 *              Pijlstraat 9                                                 *
 *              2060 Antwerpen, Belgium                                      *
 *              ph@mymail.com                                                *
 *              (+323) 231.5277                                              *
 *                                                                           *
 *  Copyright (c) 1991-96 Pieter A. Hintjens.  May be freely distributed.    *
 *                                                                           *
 *  This code was based on the book "Internetworking With TCP/IP Volume III  *
 *  Client-Server Programming And Applications BSD Socket Version" by        *
 *  Douglas E. Comer and David L. Stevens, published 1993 by Prentice-Hall   *
 *  Inc.  ISBN 0-13-020272-X.  Changes for Windows were provided by Pascal   *
 *  Antonnaux <antonnaux_pascal@msn.com>.                                    *
 *===========================================================================*/

#include "prelude.h"
#include "sockio.h"

/*  The ip_portbase is added to the port number when creating a service;     */
/*  you can set this variable before calling passive_TCP or passive_UDP.     */

int
    ip_portbase = 0;

/*  The connect_error_value holds the last recorded error cause after a      */
/*  connection attempt.                                                      */

static int
    connect_error_value = 0;

/*  Internal functions used to create passive and active connections         */

static SOCKET passive_socket (char *service, char *protocol,
                              int queue_length);
static SOCKET connect_socket (char *host, char *service, char *protocol,
                              int retry_max, int retry_delay);
static void   prepare_socket (SOCKET handle);


/*  -------------------------------------------------------------------------
 *  passive_TCP
 *
 *  Creates a passive bound TCP socket for the specified service.  Returns
 *  a socket number or INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADSERVICE       Service cannot be converted to port number
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot create the passive socket
 *      IP_BINDERROR        Cannot bind to the port
 *      IP_LISTENERROR      Cannot listen to port
 */

SOCKET
passive_TCP (
    char *service,                      /*  Service name or port as string   */
    int   queue_length                  /*  Queue length for listen()        */
)
{
    return (passive_socket (service, "tcp", queue_length));
}


/*  -------------------------------------------------------------------------
 *  passive_UDP
 *
 *  Creates a passive UDP socket for the specified service.  Returns a socket
 *  number or INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADSERVICE       Service cannot be converted to port number
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot create the passive socket
 *      IP_BINDERROR        Cannot bind to the port
 */

SOCKET
passive_UDP (
    char *service                       /*  Service name or port as string   */
)
{
    return (passive_socket (service, "udp", 0));
}


/*  -------------------------------------------------------------------------
 *  passive_socket
 *
 *  Creates a passive TCP or UDP socket.  This function allows a server
 *  program to create a master socket, so that connections can be accepted.
 *  Used by the passive_TCP and passive_UDP functions.  Returns a socket
 *  number or INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADSERVICE       Service cannot be converted to port number
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot create the passive socket
 *      IP_BINDERROR        Cannot bind to the port
 *      IP_LISTENERROR      Cannot listen to port (TCP only)
 */

SOCKET
passive_socket (
    char *service,                      /*  Service name or port as string   */
    char *protocol,                     /*  Protocol "tcp" or "udp"          */
    int   queue_length                  /*  Queue length for TCP sockets     */
)
{
    struct servent
        *pse;                           /*  Service information entry        */
    struct protoent
        *ppe;                           /*  Protocol information entry       */
    struct sockaddr_in
        sin;                            /*  Internet end-point address       */
    int
        sock_type;                      /*  Type of socket we want           */
    SOCKET
        handle;                         /*  Socket from socket() call        */

    memset ((void *) &sin, 0, sizeof (sin));
    sin.sin_family = AF_INET;
    sin.sin_addr.s_addr = INADDR_ANY;

    /*  Map service name to port number                                      */
    pse = getservbyname (service, protocol);
    if (pse)
        sin.sin_port = htons ((u_short) (ntohs (pse-> s_port) + ip_portbase));
    else
      {
        sin.sin_port = atoi (service);
        if (sin.sin_port == 0)          /*  Cannot get service entry         */
          {
            connect_error_value = IP_BADSERVICE;
            return (INVALID_SOCKET);
          }
        else
            sin.sin_port = htons ((u_short) (sin.sin_port + ip_portbase));
      }

    /*  Map protocol name to protocol number                                 */
    ppe = getprotobyname (protocol);
    if (ppe == NULL)                    /*  Cannot get protocol entry        */
      {
        connect_error_value = IP_BADPROTOCOL;
        return (INVALID_SOCKET);
      }

    /*  Use protocol to choose a socket type                                 */
    if (streq (protocol, "udp"))
        sock_type = SOCK_DGRAM;
    else
        sock_type = SOCK_STREAM;

    /*  Allocate a socket                                                    */
    handle = socket (PF_INET, sock_type, ppe-> p_proto);
    if (handle == INVALID_SOCKET)       /*  Cannot create passive socket     */
      {
        connect_error_value = IP_SOCKETERROR;
        return (INVALID_SOCKET);
      }

    /*  Bind the socket                                                      */
    if (bind (handle, (struct sockaddr *) &sin, sizeof (sin)) == SOCKET_ERROR)
      {
        connect_error_value = IP_BINDERROR;
        return (INVALID_SOCKET);        /*  Cannot bind to port              */
      }

    /*  Specify incoming queue length for stream socket                      */
    if (sock_type == SOCK_STREAM)
        if (listen (handle, queue_length) == SOCKET_ERROR)
          {
            connect_error_value = IP_LISTENERROR;
            return (INVALID_SOCKET);    /*  Cannot listen on port            */
          }

    prepare_socket (handle);            /*  Ready socket for use             */
    return (handle);
}


/*  -------------------------------------------------------------------------
 *  connect_TCP
 *
 *  Connects a TCP socket to the specified host and service.  Returns a
 *  socket number or INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADHOST          Host is not known
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot open a socket
 *      IP_CONNECTERROR     Cannot connect socket
 */

SOCKET
connect_TCP (
    char *host,
    char *service
)
{
    return (connect_socket (host, service, "tcp", 1, 0));
}


/*  -------------------------------------------------------------------------
 *  connect_UDP
 *
 *  Creates a UDP socket to the specified host and service.  Returns a
 *  socket number or INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADHOST          Host is not known
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot open a socket
 *      IP_CONNECTERROR     Cannot connect socket
 */

SOCKET
connect_UDP (
    char *host,
    char *service
)
{
    return (connect_socket (host, service, "udp", 1, 0));
}


/*  -------------------------------------------------------------------------
 *  connect_socket
 *
 *  Makes a connection to a remote TCP or UDP port.  This allows a client
 *  program to start sending information to a server.  Used by the
 *  connect_TCP and connect_UDP functions.  Returns a socket number or
 *  INVALID_SOCKET.  socket_error() may return:
 *
 *      IP_BADHOST          Host is not known
 *      IP_BADPROTOCOL      Cannot understand protocol name
 *      IP_SOCKETERROR      Cannot open a socket
 *      IP_CONNECTERROR     Cannot connect socket
 */

SOCKET
connect_socket (
    char *host,                         /*  Name of host, "" = current       */
    char *service,                      /*  Service name or port as string   */
    char *protocol,                     /*  Protocol "tcp" or "udp"          */
    int   retry_max,                    /*  Max. number of retries           */
    int   retry_delay                   /*  Delay between retries            */
)
{
    struct hostent
        *phe;
    struct servent
        *pse;
    struct protoent
        *ppe;
    struct sockaddr_in
        sin;
    char
        hostname [MAXHOSTNAMELEN + 1];  /*  Name of this system              */
    SOCKET
        handle = 0;                     /*  Socket from socket() call        */
    int
        socktype;

    memset ((void *) &sin, 0, sizeof (sin));
    sin.sin_family = AF_INET;

    /*  Map service name to a port number                                    */
    pse = getservbyname (service, protocol);
    if (pse)
        sin.sin_port = pse-> s_port;
    else
        sin.sin_port = htons ((dbyte) atoi (service));

    /*  Map host name to IP address, allowing for dotted decimal             */
    if (strused (host))
        strcpy (hostname, host);
    else
        gethostname (hostname, sizeof (hostname));

    phe = gethostbyname (hostname);
    if (phe == NULL)
        phe = gethostbyaddr (hostname, strlen (hostname), AF_INET);

    if (phe)
        memcpy ((void *) &sin.sin_addr, phe-> h_addr, phe-> h_length);
    else
      {                                 /*  Cannot map to host               */
        connect_error_value = IP_BADHOST;
        return (INVALID_SOCKET);
      }

    /*  Map protocol name to protocol number                                 */
    ppe = getprotobyname (protocol);
    if (ppe == NULL)                    /*  Cannot map protocol              */
      {
        connect_error_value = IP_BADPROTOCOL;
        return (INVALID_SOCKET);
      }

    /*  Use protocol to choose a socket type                                 */
    if (streq (protocol, "udp"))
        socktype = SOCK_DGRAM;
    else
        socktype = SOCK_STREAM;

    /*  Allocate a socket                                                    */
    while (retry_max)
      {
        handle = socket (AF_INET, socktype, ppe-> p_proto);
        if (handle == INVALID_SOCKET)   /*  Unable to open a socket          */
          {
            connect_error_value = IP_SOCKETERROR;
            return (INVALID_SOCKET);
          }

        if (connect (handle, (struct sockaddr *) &sin, sizeof (sin)) == 0)
            break;                      /*  Connected okay                   */

        /*  Retry if we have any attempts left                               */
        close (handle);
        if (--retry_max == 0)           /*  Connection failed                */
          {
            connect_error_value = IP_CONNECTERROR;
            return (INVALID_SOCKET);
          }
        sleep (retry_delay);
      }
    prepare_socket (handle);            /*  Ready socket for use             */
    return (handle);
}


/*  -------------------------------------------------------------------------
 *  accept_socket
 *
 *  Accepts a connection on a specified master socket.  If you do not want
 *  to wait on this call, use select() to poll the socket until there is an
 *  incoming request, then call accept_socket.  Returns the number of the
 *  new slave socket, or INVALID_SOCKET.  If there is an error on the accept
 *  this function returns -1.  You can handle errors as fatal except for
 *  EAGAIN which indicates that the operation would cause a non-blocking
 *  socket to block.
 */

SOCKET
accept_socket (SOCKET master_socket)
{
    SOCKET
        slave_socket;                   /*  Connected slave socket           */
    struct sockaddr_in
        sin;                            /*  Address of connecting party      */
    int
        sin_length,                     /*  Length of address                */
        sock_errno;

    sin_length = sizeof (sin);
    slave_socket = accept (master_socket,
                          (struct sockaddr *) &sin, &sin_length);

#if (defined (__WINDOWS__))
    if (slave_socket == INVALID_SOCKET)
      {
        sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
      }
    else
        prepare_socket (slave_socket);
#   endif

    return (slave_socket);
}


/*  -------------------------------------------------------------------------
 *  prepare_socket
 *
 *  Does any system-specific work required to prepare a socket for normal
 *  use.  In Windows we have to set the socket to nonblocking mode.
 */

 static void
 prepare_socket (SOCKET handle)
 {
#   if (defined (__WINDOWS__))
    /*  Redirect events and set non-blocking mode                            */
    if (handle != INVALID_SOCKET)
        WSAAsyncSelect (handle, GetDesktopWindow (), 0,
                        FD_READ | FD_WRITE | FD_ACCEPT | FD_CLOSE);
#   endif
 }


/*  -------------------------------------------------------------------------
 *  init_sockets
 *
 *  Initialise the internet protocol.  On most systems this is a null call.
 *  On some systems this loads dynamic libraries.  Returns -1 if there was
 *  an error, or 0 if everything was okay.
 */

int
init_sockets (void)
{
#if (defined (__WINDOWS__))
    WORD
        wVersionRequested;              /*  We want Winsock 1.1              */
    WSADATA
        wsaData;

    wVersionRequested = MAKEWORD (1, 1);
    return (WSAStartup (wVersionRequested, &wsaData) == 0? 0: -1);
#else
    return (0);
#endif
}


/*  -------------------------------------------------------------------------
 *  term_sockets
 *
 *  Shuts-down the internet protocol.  On most systems this is a null call.
 *  On some systems this unloads dynamic libraries.  Returns -1 if there was
 *  an error, or 0 if everything was okay.
 */

int
term_sockets (void)
{
#if (defined (__WINDOWS__))
    WSACleanup ();
#endif
    return (0);
}


/*  -------------------------------------------------------------------------
 *  connect_error
 *
 *  Returns the last error code from one of the connection functions.  For
 *  portability in a multithreaded environment, call immediately after the
 *  call to the connection function.
 */
int
connect_error (void)
{
    return (connect_error_value);
}


/*  -------------------------------------------------------------------------
 *  read_socket
 *
 *  Reads data from the socket.  On UNIX, passes through to the standard
 *  read function; some other systems have particular ways of accessing
 *  sockets.  If there is an error on the read this function returns -1.
 *  You can handle errors as fatal except for EAGAIN which indicates that
 *  the operation would cause a non-blocking socket to block.
 */

int
read_socket (
    SOCKET handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer to receive data           */
    size_t length                       /*  Maximum amount of data to read   */
)
{
#if (defined (__UNIX__) || defined (__VMS__))
    return (read (handle, buffer, length));
#elif (defined (__WINDOWS__))
    int
        rc,
        sock_errno;

    rc = recv (handle, buffer, length, 0);
    if (rc == SOCKET_ERROR)
      {
        sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
      }
    return (rc);
#else
    return (-1);                        /*  Sockets not supported            */
#endif
}


/*  -------------------------------------------------------------------------
 *  write_socket
 *
 *  Writes data from the socket.  On UNIX, passes through to the standard
 *  write function; some other systems have particular ways of accessing
 *  sockets.  If there is an error on the write this function returns -1.
 *  You can handle errors as fatal except for EAGAIN which indicates that
 *  the operation would cause a non-blocking socket to block.
 */

int
write_socket (
    SOCKET handle,                      /*  Socket handle                    */
    void  *buffer,                      /*  Buffer containing data           */
    size_t length                       /*  Amount of data to write          */
)
{
#if (defined (__UNIX__) || defined (__VMS__))
    return (write (handle, buffer, length));
#elif (defined (__WINDOWS__))
    int
        rc,
        sock_errno;

    rc = send (handle, buffer, length, 0);
    if (rc == SOCKET_ERROR)
      {
        sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
      }
    return (rc);
#else
    return (-1);                        /*  Sockets not supported            */
#endif
}


/*  -------------------------------------------------------------------------
 *  close_socket
 *
 *  Closes the socket.  On UNIX, passes through to the standard close
 *  function; some other systems have particular ways of accessing sockets.
 *  If there is an error on the close this function returns -1.  You can
 *  handle errors as fatal except for EAGAIN which indicates that the
 *  operation would cause a non-blocking socket to block.
 */

int
close_socket (
    SOCKET handle                       /*  Socket handle                    */
)
{
#if (defined (__UNIX__) || defined (__VMS__))
    return (close (handle));
#elif (defined (__WINDOWS__))
    int
        rc,
        sock_errno;

    rc = closesocket (handle);
    if (rc == SOCKET_ERROR)
      {
        sock_errno = WSAGetLastError ();
        if (sock_errno == WSAEWOULDBLOCK || sock_errno == WSAEINPROGRESS)
            errno = EAGAIN;
      }
    return (rc);
#else
    return (-1);                        /*  Sockets not supported            */
#endif
}


/*  -------------------------------------------------------------------------
 *  sockmsg
 *
 *  Returns a string describing the cause of the last fatal error to occur
 *  a socket.  Should be called directly after a socket i/o operation; if you
 *  do other i/o operations or allow other threads to proceed in the meantime,
 *  the returned string may be incorrect.
 */

char *
sockmsg (void)
{
#if (defined (__WINDOWS__))
    char
        *message;

    switch (WSAGetLastError ())
      {
        case WSAEINTR:           message = "WSAEINTR";           break;
        case WSAEBADF:           message = "WSAEBADF";           break;
        case WSAEACCES:          message = "WSAEACCES";          break;
        case WSAEFAULT:          message = "WSAEFAULT";          break;
        case WSAEINVAL:          message = "WSAEINVAL";          break;
        case WSAEMFILE:          message = "WSAEMFILE";          break;
        case WSAEWOULDBLOCK:     message = "WSAEWOULDBLOCK";     break;
        case WSAEINPROGRESS:     message = "WSAEINPROGRESS";     break;
        case WSAEALREADY:        message = "WSAEALREADY";        break;
        case WSAENOTSOCK:        message = "WSAENOTSOCK";        break;
        case WSAEDESTADDRREQ:    message = "WSAEDESTADDRREQ";    break;
        case WSAEMSGSIZE:        message = "WSAEMSGSIZE";        break;
        case WSAEPROTOTYPE:      message = "WSAEPROTOTYPE";      break;
        case WSAENOPROTOOPT:     message = "WSAENOPROTOOPT";     break;
        case WSAEPROTONOSUPPORT: message = "WSAEPROTONOSUPPORT"; break;
        case WSAESOCKTNOSUPPORT: message = "WSAESOCKTNOSUPPORT"; break;
        case WSAEOPNOTSUPP:      message = "WSAEOPNOTSUPP";      break;
        case WSAEPFNOSUPPORT:    message = "WSAEPFNOSUPPORT";    break;
        case WSAEAFNOSUPPORT:    message = "WSAEAFNOSUPPORT";    break;
        case WSAEADDRINUSE:      message = "WSAEADDRINUSE";      break;
        case WSAEADDRNOTAVAIL:   message = "WSAEADDRNOTAVAIL";   break;
        case WSAENETDOWN:        message = "WSAENETDOWN";        break;
        case WSAENETUNREACH:     message = "WSAENETUNREACH";     break;
        case WSAENETRESET:       message = "WSAENETRESET";       break;
        case WSAECONNABORTED:    message = "WSAECONNABORTED";    break;
        case WSAECONNRESET:      message = "WSAECONNRESET";      break;
        case WSAENOBUFS:         message = "WSAENOBUFS";         break;
        case WSAEISCONN:         message = "WSAEISCONN";         break;
        case WSAENOTCONN:        message = "WSAENOTCONN";        break;
        case WSAESHUTDOWN:       message = "WSAESHUTDOWN";       break;
        case WSAETOOMANYREFS:    message = "WSAETOOMANYREFS";    break;
        case WSAETIMEDOUT:       message = "WSAETIMEDOUT";       break;
        case WSAECONNREFUSED:    message = "WSAECONNREFUSED";    break;
        case WSAELOOP:           message = "WSAELOOP";           break;
        case WSAENAMETOOLONG:    message = "WSAENAMETOOLONG";    break;
        case WSAEHOSTDOWN:       message = "WSAEHOSTDOWN";       break;
        case WSAEHOSTUNREACH:    message = "WSAEHOSTUNREACH";    break;
        case WSAENOTEMPTY:       message = "WSAENOTEMPTY";       break;
        case WSAEPROCLIM:        message = "WSAEPROCLIM";        break;
        case WSAEUSERS:          message = "WSAEUSERS";          break;
        case WSAEDQUOT:          message = "WSAEDQUOT";          break;
        case WSAESTALE:          message = "WSAESTALE";          break;
        case WSAEREMOTE:         message = "WSAEREMOTE";         break;
        case WSAEDISCON:         message = "WSAEDISCON";         break;
        case WSASYSNOTREADY:     message = "WSASYSNOTREADY";     break;
        case WSAVERNOTSUPPORTED: message = "WSAVERNOTSUPPORTED"; break;
        case WSANOTINITIALISED:  message = "WSANOTINITIALISED";  break;
        default:                 message = "No error";
      }
    return (message);
#else
    return (strerror (errno));
#endif
}
