/*===========================================================================*
 *                                                                           *
 *  smtechod.c  Multithreaded echo daemon                                    *
 *                                                                           *
 *  Written:    96/02/11    Pieter Hintjens                                  *
 *  Revised:    96/03/28                                                     *
 *                                                                           *
 *===========================================================================*/

#include "prelude.h"                    /*  Universal include file           */
#include "smtlib.h"                     /*  Libero threads functions         */
#include "sockio.h"                     /*  Socket i/o functions             */

/*- Structure definitions ---------------------------------------------------*/

#define BUFFER_SIZE     512

typedef struct                          /*  Thread context block:            */
  {
    t_event
        initial_event;                  /*    Initial event                  */
    char
        *buffer;                        /*    Input buffer                   */
    int
        handle,                         /*    Handle for file i/o            */
        readsize,                       /*    Size of input message          */
        connection;                     /*    1..n for slave threads         */
    SOCKET
        socknbr;                        /*    Handle for socket i/o          */
  } TCBLOCK;


/*- Internal messages -------------------------------------------------------*/

enum
  {
    MSG_BASE = MSG_USER_BASE,           /*  Define messages here             */
    MSG_LOG                             /*  Write record to logfile          */
  };


/*- Function prototypes -----------------------------------------------------*/


static void     logprintf     (char *format, ...);
static char    *time_now      (void);
static TCBLOCK *new_thread    (t_event initial_event);


/*- Global variables used in this source file only --------------------------*/

static char
    *logfile_name = "smtechod.log";     /*  Name of log file                 */

static int
    connections,                        /*  Number of connections so far     */
    feedback;                           /*  Feedback for calling program     */

static int                              /*  Command line arguments           */
    argc;                               /*  We copy them here so that all    */
static char                             /*    modules (not just main())      */
    **argv;                             /*    can access them.               */

#include "smtechod.d"                   /*  Include dialog data              */


/********************************   M A I N   ********************************/

int main (int p_argc, char *p_argv [])
{
    feedback = 0;                       /*  No errors so far                 */
    argc = p_argc;                      /*  Copy arguments                   */
    argv = p_argv;

#   include "smtechod.i"                /*  Include dialog interpreter       */
}


/*************************   INITIALISE THE PROGRAM   ************************/

MODULE initialise_the_program (void)
{
    /*  Initialise sockets, and abort if there was a problem                 */
    if (init_sockets ())
      {
        printf ("Cannot initialise sockets\n");
        exit (RET_ERROR);
      }
        
    /*  Create initial threads                                               */
    new_thread (master_event);          /*  Handles master socket            */
    new_thread (logging_event);         /*  Handles log file                 */
    connections = 0;                    /*  We number each connection        */
}

static TCBLOCK *new_thread (t_event initial_event)
{
    TCBLOCK
        *tcb;                           /*  New thread context block         */

    tcb = create_thread (NULL);         /*  Let create_thread allocate TCB   */
    tcb-> initial_event = initial_event;
    return (tcb);
}


/*************************   INITIALISE THE THREAD   *************************/

MODULE initialise_the_thread (TCBLOCK *context)
{
    if (context-> socknbr)
      {
        context-> connection = ++connections;
        logprintf ("I: started connection %d", context-> connection);
      }
    the_next_event = context-> initial_event;
}


/*  -------------------------------------------------------------------------
 *  logprintf
 *
 *  Sends a message to the log file.  Syntax of this call is the same as for
 *  printf except that each message is always prefixed by the date and time
 *  and ends in a newline.
 */

local
logprintf (char *format, ...)
{
    static char
        formatted [LINE_MAX];           /*  Formatted string                 */
    va_list
        argptr;                         /*  Argument list pointer            */

    strcpy   (formatted, time_now ());  /*  Start with date and time         */
    strcat   (formatted, ": ");         /*  Add a colon and a space          */
    va_start (argptr, format);          /*  Start variable args processing   */
    vsprintf (formatted + strlen (formatted), format, argptr);
    va_end   (argptr);                  /*  End variable args processing     */
    strcat   (formatted, "\n");         /*  Add a newline                    */

    printf (formatted);                 /*  Just for debugging...            */
    send_imsg (MSG_LOG, formatted, strlen (formatted));
}


/*  -------------------------------------------------------------------------
 *  time_now
 *
 *  Returns the current date and time formatted as: "yy/mm/dd hh:mm:ss".
 *  The formatted time is in a static string that each call overwrites.
 */

static
char *time_now (void)
{
    static char
        formatted_time [18];
    time_t
        time_secs;
    struct tm
        *time_struct;

    time_secs   = time (NULL);
    time_struct = localtime (&time_secs);

    sprintf (formatted_time, "%2d/%02d/%02d %2d:%02d:%02d",
                              time_struct-> tm_year,
                              time_struct-> tm_mon + 1,
                              time_struct-> tm_mday,
                              time_struct-> tm_hour,
                              time_struct-> tm_min,
                              time_struct-> tm_sec);
    return (formatted_time);
}


/*****************************   OPEN LOG FILE   *****************************/

MODULE open_log_file (TCBLOCK *context)
{
    context-> handle = lazy_creat (logfile_name, S_IREAD | S_IWRITE);
    if (io_completed)
      {
        if (context-> handle < 0)
          {
            logprintf ("E: could not open logfile: %s", strerror (errno));
            raise_exception (exception_event);
          }
      }
}


/***************************   OPEN MASTER SOCKET   **************************/

MODULE open_master_socket (TCBLOCK *context)
{
    char
        *master_socket;

    if (argc > 1)
        master_socket = argv [1];
    else
        master_socket = "5001";

    context-> socknbr = passive_TCP (master_socket, 5);
    if (context-> socknbr == INVALID_SOCKET)
      {
        logprintf ("E: could not open socket: %s", sockmsg ());
        logprintf ("E: error from passive_TCP: %d", connect_error ());
        raise_exception (exception_event);
      }
    else
        logprintf ("I: opened master socket %s", master_socket);
}


/**********************   WAIT SOCKET READY FOR INPUT   **********************/

MODULE wait_socket_ready_for_input (TCBLOCK *context)
{
    expect_input (context-> socknbr);
}


/**********************   WAIT SOCKET READY FOR OUTPUT   *********************/

MODULE wait_socket_ready_for_output (TCBLOCK *context)
{
    expect_output (context-> socknbr);
}


/*************************   ACCEPT CONNECT REQUEST   ************************/

MODULE accept_connect_request (TCBLOCK *context)
{
    int
        slave_socket;                   /*  Connected socket                 */
    TCBLOCK
        *tcb;                           /*  Context of created thread        */

    slave_socket = accept_socket (context-> socknbr);
    if (slave_socket != INVALID_SOCKET)
      {
        the_next_event = ok_event;
        tcb = new_thread (slave_event);
        if (tcb)
          {
            tcb-> socknbr = slave_socket;
            tcb-> buffer  = (char *) malloc (BUFFER_SIZE + 1);
            malloc_count++;             /*  Maintain statistics              */
          }
        else                            /*  Could not allocate thread        */
            close_socket (slave_socket);
      }
    else
    if (errno == EAGAIN)
        the_next_event = retry_event;
    else
      {
        logprintf ("E: could not accept connection: %s", sockmsg ());
        raise_exception (exception_event);
      }
}


/*************************   READ INPUT FROM SOCKET   ************************/

MODULE read_input_from_socket (TCBLOCK *context)
{
    context-> readsize = read_socket (context-> socknbr,
                                      context-> buffer, BUFFER_SIZE);
    if (context-> readsize > 0)
        the_next_event = ok_event;
    else
    if (context-> readsize == 0)
        the_next_event = finished_event;
    else
        the_next_event = error_event;
}


/**************************   ECHO INPUT TO OUTPUT   *************************/

MODULE echo_input_to_output (TCBLOCK *context)
{
    write_socket (context-> socknbr, context-> buffer, context-> readsize);
}


/****************************   CLOSE THE SOCKET   ***************************/

MODULE close_the_socket (TCBLOCK *context)
{
    if (context-> buffer)
      {
        free (context-> buffer);
        free_count++;                   /*  Maintain statistics              */
        context-> buffer = NULL;
      }
    if (context-> socknbr != INVALID_SOCKET)
      {                                 
        close_socket (context-> socknbr);
        context-> socknbr = 0;
      }
    switch (context-> initial_event)
      {
        case master_event:
            if (dialog_signal == SIGINT)
                logprintf ("W: interrupted");
            else
            if (dialog_signal == SIGTERM)
                logprintf ("W: terminated");
            else
            if (dialog_signal == SIGSEGV)
                logprintf ("W: segment violation");

            logprintf ("I: closed master socket");
            break;

        case slave_event:
            logprintf ("I: client connection %d ended", context-> connection);
            break;
      }
}


/**********************   WAIT FOR OUTPUT FOR LOGFILE   **********************/

MODULE wait_for_output_for_logfile (TCBLOCK *context)
{
    expect_imsg (MSG_LOG);
}


/************************   WRITE OUTPUT TO LOGFILE   ************************/

MODULE write_output_to_logfile (TCBLOCK *context)
{
    int
        rc;                             /*  Return code from lazy_write      */

    rc = lazy_write (context-> handle, imsg_body, imsg_size);
    if (io_completed)
        if (rc >= 0)                    /*  0 or more bytes written ok       */
            the_next_event = ok_event;
        else                            /*  -1 signals error                 */
            the_next_event = error_event;
}


/***********************   DISCARD OUTPUT FOR LOGFILE   **********************/

MODULE discard_output_for_logfile (TCBLOCK *context)
{
    the_next_event = ok_event;          /*  Throw-away message and loop      */
}


/*************************   TERMINATE THE THREAD   **************************/

MODULE terminate_the_thread (TCBLOCK *context)
{
    the_next_event = terminate_event;
}


/*************************   SHUT DOWN THE PROGRAM   *************************/

MODULE shut_down_the_program (TCBLOCK *context)
{
    shutdown_dialog ();                 /*  Kill process neatly              */
}


/**************************   SHUTDOWN THE THREAD   **************************/

MODULE shutdown_the_thread (TCBLOCK *context)
{
    /*  Shut-down the socket if the thread is connected to a socket          */
    if (context-> socknbr > 0)
      {
        close_the_socket (context);
        terminate_the_thread (context);
      }
}


/***************************   GET EXTERNAL EVENT   **************************/

MODULE get_external_event (TCBLOCK *context)
{
}


/*************************   TERMINATE THE PROGRAM    ************************/

MODULE terminate_the_program (void)
{
    term_sockets ();                    /*  Terminate socket i/o             */

    printf ("Statistics:\n");
    printf ("   Calls to malloc() . . . . %ld\n", malloc_count);
    printf ("   Calls to free() . . . . . %ld\n", free_count);
    printf ("   Threads created . . . . . %ld\n", count_create_threads);
    printf ("   Messages created  . . . . %ld\n", count_create_imsgs);
    printf ("   I/O requests handled  . . %ld\n", count_io_requests);
    printf ("   Thread switches . . . . . %ld\n", count_thread_switches);
    printf ("   Highest no. threads . . . %ld\n", max_total_threads);
    printf ("   Highest no. messages  . . %ld\n", max_total_imsgs);
}
